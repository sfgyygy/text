//
//  BanbenGengxin.h
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#define kHarpyAlertViewTitle        @"版本升级"
#define kHarpyCancelButtonTitle     @"下次再说"
#define kHarpyUpdateButtonTitle     @"马上升级"
#define kAppID                      @""

    
#import <Foundation/Foundation.h>
#import "Danli.h"

@interface BanbenGengxin : NSObject

XMGSingletoH
/**
 *  判断版本更新
 */
-(void)test;

@end
