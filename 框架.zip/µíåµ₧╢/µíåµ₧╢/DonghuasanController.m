//
//  DonghuasanController.m
//  框架
//
//  Created by Apple on 16/9/5.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "DonghuasanController.h"
#import "LeafProgressView.h"

@interface DonghuasanController ()

@property (nonatomic, strong) LeafProgressView *progress;

@property (nonatomic, assign) CGFloat rate;

@end

@implementation DonghuasanController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
    
    self.progress = [[LeafProgressView alloc]initWithFrame:CGRectMake(36, 200, 248, 35)];
    [self.view addSubview:self.progress];
    
    [_progress startLoading];
    
    [self.view addSubview:[[UILabel alloc]initWithFrame:CGRectMake( 36 , 250, 150, 25) text:@"点击屏幕查看效果"]];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    _rate += 0.01;
    
    [_progress setProgress:_rate];
    if (_rate >= 0.999) {
        _rate = 0 ;
        [_progress stopLoading];
    }
}

@end
