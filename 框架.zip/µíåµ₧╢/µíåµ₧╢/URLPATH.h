


/**
 *  这类项目中的所有的接口地址
 *
 *  @param ...
 *
 *  @return url
 */

#ifndef URLPATH_h
#define URLPATH_h

#ifdef DEBUG //调试状态 打开LOG功能
 #define MyLog(...) NSLog(__VA_ARGS__)
 #define URLIP @""
 #define TUPIANURL(STR) [NSString stringWithFormat:@"%@",STR]
#else // 发布状态, 关闭LOG功能
 #define MyLog(...)
 #define URLIP @""
 #define TUPIANURL(STR) [NSString stringWithFormat:@"%@",STR]
#endif

//接口地址的url
#define URL(STR)  [NSString stringWithFormat:@"%@%@",URLIP,STR]



#endif /* URLPATH_h */
