

#import "NewFeatureViewController.h"

//#define NewFeatureImageCount (2)

@interface NewFeatureViewController ()
{
    NSArray *_arrayPath;
}
@property (nonatomic,copy)NSString *path ;

@property(nonatomic,assign)int index;

@property(nonatomic,retain)UIScrollView *sv;

@property (nonatomic, retain) NSTimer *timer;

@property(nonatomic,retain)UIImageView *imageView;

@property(nonatomic,retain)NSString *imagePath;

@end

@implementation NewFeatureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sv = [[UIScrollView alloc] init];
    _sv.frame = self.view.bounds;
    _sv.pagingEnabled = YES;
    //添加图片
    _arrayPath=@[@"new_feature_1",@"new_feature_2",@"new_feature_3"];
    for (int i=0; i<_arrayPath.count; i++) {
        [self imageViewpath:_arrayPath[i] index:i view:_sv];
    }
    [self.view addSubview:_sv];
    if (!self.timer) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
    }
}
/**
 *  用户点击体验按钮，立即进入应用程序界面
 */
- (void)btnClick
{
    [_timer setFireDate:[NSDate distantFuture]];
    [self.delegate didtext];
}
//创建imageView
-(UIScrollView *)imageViewpath:(NSString *)stringPath index:(int )index view:(UIScrollView *)sv
{
    // 创建滚动视图展示的新特性图片
    CGFloat imageViewY = 0;
    CGFloat imageViewW = [UIScreen mainScreen].bounds.size.width;
    CGFloat imageViewH = [UIScreen mainScreen].bounds.size.height;
    UIImageView *imageView = [[UIImageView alloc] init];
    CGFloat imageViewX = imageViewW * index;
    imageView.frame = CGRectMake(imageViewX, imageViewY, imageViewW, imageViewH);
    imageView.image=[UIImage imageNamed:stringPath];
    [sv addSubview:imageView];
    // 最后一张图片上添加按钮
    if (index ==_arrayPath.count-1&&index!=0) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
        //按钮的位置
        btn.titleLabel.font = [UIFont systemFontOfSize:30];
        [btn setTitleColor:[UIColor whiteColor] forState:0];
        [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
        imageView.userInteractionEnabled = YES;
        [imageView addSubview:btn];
    }
    sv.showsHorizontalScrollIndicator=NO;
    sv.bounces=NO;
    sv.contentSize=CGSizeMake(imageViewW * (index+1), 0);
    return sv;
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)updateTimer
{
    if (_sv.contentOffset.x /self.view.frame.size.width==2) {
        [_timer setFireDate:[NSDate distantFuture]];
        [self.delegate didtext];
    }else if(_sv.contentOffset.x /self.view.frame.size.width<2){
        [UIView animateWithDuration:0.5 animations:^(void){
            _sv.contentOffset=CGPointMake(self.view.bounds.size.width * ((_sv.contentOffset.x /self.view.bounds.size.width)+1), 0);
        }];
    }
}
-(void)dealloc
{
    [_timer setFireDate:[NSDate distantFuture]];
}

@end
