

#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)

#import "MyTableViewCell.h"

@interface MyTableViewCell ()

@end

@implementation MyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //cell不可点
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self createCell];
    }
    return self;
}
-(void)createCell{
    NSLog(@"儿子要重写写这个方法");
}
-(void)createcell_h:(CGFloat)cellh bgcolor:(UIColor *)bgcolor xian_h:(CGFloat)xian_h{
    self.model.CELL_H = cellh;
    CGRect Frame=CGRectMake(0, cellh - xian_h, SCREEN_WIDTH, xian_h);
    if (_xianView) {
        _xianView.frame=Frame;
    }else {
        _xianView=[[UIView alloc]initWithFrame:Frame];
        _xianView.backgroundColor=bgcolor ;
        [self addSubview:_xianView];
    }
}
@end
