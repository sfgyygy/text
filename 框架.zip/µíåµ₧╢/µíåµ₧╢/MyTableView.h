
//-----------------------------自定义的tableview--------------------------
#define TABLEVIEW_PAGE  @"cur"
#define TABLEVIEW_BGCOLOR [UIColor groupTableViewBackgroundColor]
#define TABLEVIEW_BGIMAGE @""

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "MJRefresh.h"
#import "MyTableViewModel.h"
#import "MyTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN
@class MyTableView;

@protocol MyTableViewDelegate <NSObject>

@optional
/****
 CELL 点击的返回
*/
-(void)MytableView:(MyTableView *)tableView model:(nullable MyTableViewModel *)myTableViewModel cell:(nullable MyTableViewCell *)cell;
/***
错误信息
 */
-(void)MytableView:(MyTableView *)tableView Myerror:(NSString *)Myerror;
//我下载好数据
-(void)getdatasOK;
@end

@interface MyTableView : UIView
//代理
@property(nonatomic,assign)id<MyTableViewDelegate,MyTableViewCellDelegate>delegate;
//创建
-(instancetype)initWithFrame:(CGRect)frame URL:(nullable NSString *)url cellname:(NSString *)cellname model:(NSString *)model data:(NSString *)data;
/**
 *  请求地址
 */
@property(nonatomic,copy)NSString *url;
/**
 *  cell的名称
 */
@property(nonatomic,copy)NSString *cellname;
/**
 *  下载数据的数据模型model
 */
@property(nonatomic,copy)NSString *model;
/**
 *  下载获取的数据默认取值的键
 */
@property(nonatomic,copy)NSString *data;
/**
 *  下载获取的数据取值的键2
 */
@property(nonatomic,copy)NSString *data1;
/**
 *  下载没有数据的占位图片
 */
@property(nonatomic,retain)UIImage * Bgimage ;
/**
 *  下载没有数据的背景显示图片view
 */
@property(nonatomic,retain)UIImageView * BgImageView;
/**
 *  tableview的头部view
 */
@property(nonatomic,retain)UIView * hearView;
/**
 *  get 请求数据
 *
 *  @param index index >  0  创建上拉加载 下拉刷新
 */
-(void)getdownDatas:(int)index;
/**
 *  创建tableview
 *
 *  @param index index >  0  创建上拉加载 下拉刷新
 */
-(void)createTableView:(int)index;
/**
 *  post请求
 *
 *  @param index index index >  0  创建上拉加载 下拉刷新
 *  @param dict  长传的数据
 */
-(void)postownDatas:(int)index dict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END