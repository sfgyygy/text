
@interface UIButton (Helpr)

NS_ASSUME_NONNULL_BEGIN
/****
 位子 文字 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:( NSString *)text id:(id)delegate sel:(SEL)sel;
/****
 位子 文字 大小 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size id:(id)delegate sel:(SEL)sel;
/****
 位子 文字 颜色 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text  textColor:(nullable UIColor *)textColor id:(id)delegate sel:(SEL)sel;
/****
 位子 文字 大小 颜色 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text  size:(CGFloat)size textColor:(nullable UIColor *)textColor id:(id)delegate sel:(SEL)sel;
/****
 位子 文字  大小 颜色 背景颜色 圆角 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size textColor:(UIColor *)textColor beijingColor:(UIColor *)bejingColor  cornerRadius:(CGFloat)cornerRadius id:(id)delegate sel:(SEL)sel;
/****
 位子 文字 大小 颜色 背景颜色 边框颜色 圆角 代理 方法
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size textColor:(UIColor *)textColor beijingColor:(UIColor *)bejingColor  biankuangColor:(nullable UIColor *)biankuangColor cornerRadius:(CGFloat)cornerRadius id:(id)delegate sel:(SEL)sel;
/**
 *  背景图片 代理 位子
 *
 *  @param frame     位子
 *  @param backImage 图片
 *  @param delegate  代理
 *  @param sel       代理
 *
 *  @return self
 */
-(instancetype)initWithFrame:(CGRect)frame backImage:(UIImage *)backImage id:(id)delegate sel:(SEL)sel;

/**
 *  设置背景图片 保持沙盒 缓存
 *
 *  @param image 占位图片
 *  @param url   图片地址
 */
-(void)setBackgroundImage:(nullable UIImage *)image withUrl:(NSString *)url;
/**
 *  设置背景图片 保存沙盒  缓存  默认展位图片
 *
 *  @param url 图片地址
 */
-(void)setBackgroundWithUrl:(NSString *)url;
/**
 *  设置按钮的文字颜色不一样
 *
 *  @param str      内容
 *  @param kaiindex 第1段内容的介绍下标
 *  @param kaicolor 第1段内容的颜色
 *  @param jieindex 第2段内容的介绍下表
 *  @param jiecolor 第2段内容的颜色
 */
-(void)addAttr:(NSString *)str kaiindex:(int)kaiindex kaicolor:(UIColor *)kaicolor  jieindex:(int)jieindex jiecolor:(UIColor *)jiecolor;

NS_ASSUME_NONNULL_END

@end

/**
 *  这个是验证码的按钮
 *
 *  @param 100 验证码的按钮
 *  @param 100 验证码的按钮
 *  @param 100 验证码的按钮
 *
 *  @return 验证码的按钮
 */


@interface YanzhenButton : UIButton

NS_ASSUME_NONNULL_BEGIN
/**
 *  设置验证码 显示的总时间
 */
@property(nonatomic,assign)int  time;

@property(nonatomic,retain)NSTimer*  timer;

-(void)openTimer;

-(void)stopTimer;
NS_ASSUME_NONNULL_END
@end
