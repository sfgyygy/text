//
//  UIImage+Helpr.m
//  个人
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "UIImage+Helpr.h"

@implementation UIImage (Helpr)
//下载图片
+(nullable UIImage *)setimageWithURL:(NSString *)url{
    NSData *data=[self images][url];
    if (data) {
        return [UIImage imageWithData:data];
    }
    NSString *cachesPath=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filename=[cachesPath stringByAppendingPathComponent:[url lastPathComponent]];
    data=[NSData dataWithContentsOfFile:filename ];
    if (!data) {
        data=[NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
        if (data == nil) {
            return nil;
        }
        if ([self sd_contentTypeForImageData:data]==nil) {
            return nil;
        }
        [data writeToFile:filename atomically:YES];
        [self images][url]=data;  
    }
    return [UIImage imageWithData:data];
}
//删除指定图片
+(void)removeimageWithURL:(NSString *)url{
    NSString *cachesPath=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filename=[cachesPath stringByAppendingPathComponent:[url lastPathComponent]];
    [[NSFileManager defaultManager]removeItemAtPath:filename error:nil];
}
//删除全部图片
+(void)removeAllimage{
    NSString *cachesPath=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    [[NSFileManager defaultManager]removeItemAtPath:cachesPath error:nil];
}
//缓存图片字典
+(NSMutableDictionary  *)images{
    static NSMutableDictionary *dict=nil;
    if (dict==nil) {
        dict=[NSMutableDictionary dictionaryWithCapacity:10];
    }
    return dict;
}
//判断是不是图片
+ (NSString *)sd_contentTypeForImageData:(NSData *)data {
    uint8_t c;
    [data getBytes:&c length:1];
    switch (c) {
        case 0xFF:
            return @"image/jpeg";
        case 0x89:
            return @"image/png";
        case 0x47:
            return @"image/gif";
        case 0x49:
        case 0x4D:
            return @"image/tiff";
        case 0x52:
            if ([data length] < 12) {
                return nil;
            }
            NSString *testString = [[NSString alloc] initWithData:[data subdataWithRange:NSMakeRange(0, 12)] encoding:NSASCIIStringEncoding];
            if ([testString hasPrefix:@"RIFF"] && [testString hasSuffix:@"WEBP"]) {
                return @"image/webp";
            }
            return nil;
    }
    
    return nil;
}
+(UIActivityIndicatorView *)downloadingImageActivityIndicatorView:(CGRect)fram
{
    UIActivityIndicatorView *activ=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    activ.frame=fram;
    activ.hidesWhenStopped=YES;
    [activ startAnimating];
    return activ;
}

@end
