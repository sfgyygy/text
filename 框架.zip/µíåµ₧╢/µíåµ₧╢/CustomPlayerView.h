

#import <UIKit/UIKit.h>

#import <AVFoundation/AVFoundation.h>

@interface CustomPlayerView : UIView

//从外部传入AVPlayer对象,然后放到layer上
@property (nonatomic, strong) AVPlayer *player;


@end
