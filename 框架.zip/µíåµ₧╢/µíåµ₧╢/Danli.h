#ifndef Danli_h
#define Danli_h

//单例宏
#define XMGSingletonH(name) +(instancetype)shared##name;

#define XMGSingletonM(name)  \
static id _instace;   \
+(instancetype)allocWithZone:(struct _NSZone *)zone{\
static dispatch_once_t  onceToken;\
dispatch_once(&onceToken, ^{\
_instace=[super allocWithZone: zone];\
});\
return   _instace;\
}\
+(instancetype)shared##name{\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
_instace=[[self alloc]init];\
});\
return _instace;\
}\
-(id)copyWithZone:(NSZone *)zone{\
return _instace;\
}

#define XMGSingletoH  XMGSingletonH(Instance)
#define XMGSingletoM  XMGSingletonM(Instance)

#endif /* Danli_h */
