

#import "PhotoViewController.h"
@interface PhotoViewController ()
{
    UIImageView *_imgv;
}
@end

@implementation PhotoViewController

-(void)setImageName:(NSString *)imageName
{
    _imageName = imageName;
    _imgv = [[UIImageView alloc]initWithFrame:self.bounds];
    [self addSubview:_imgv];
    [_imgv setimage:[UIImage imageNamed:@"我的背景图"] withurl:TUPIANURL(_imageName)];
}

@end
