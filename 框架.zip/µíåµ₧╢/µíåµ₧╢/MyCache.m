
#import "MyCache.h"

@interface MyCache ()
/**
 *  保存请求的缓存地址
 */
@property(nonatomic,retain)NSMutableDictionary * cacheDict;

@end


@implementation MyCache
XMGSingletoM
-(NSMutableDictionary *)cacheDict
{
    if (_cacheDict == nil ) {
        _cacheDict = [NSMutableDictionary dictionaryWithCapacity:10];
    }
    return _cacheDict;
}

-(void)setObject:( id)value forKey:(NSString *)url{
    [self.cacheDict setObject:value forKey:url];
}
/**
 *  保存缓存数据
 */
-(id)objectForKey:(NSString *)url{
    return [self.cacheDict objectForKey:url];
}
/**
 *  移除缓存数据
 */
-(void)removeKey:(NSString *)url{
    [self.cacheDict removeObjectForKey:url];
}
/**
 *  移除所有缓存数据
 */
-(void)removeallKey{
    [self.cacheDict removeAllObjects];
}

//检测网络
-(void)Detectnetwork
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager.reachabilityManager startMonitoring];
    [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWWAN:
                self.status = 3;
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                self.status = 2;
                break;
            case AFNetworkReachabilityStatusUnknown:
                self.status = 1;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                self.status = -1;
                break;
        }
    }];
}
@end


