//
//  MoxingController.h
//  个人
//
//  Created by Macintosh HD on 16/6/29.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "BaseViewController.h"

@interface MoxingController : BaseViewController

@end
