
#import "RLCView.h"
#import "RLCButton.h"
#import "RLCMyButton.h"

@interface RLCView ()<RLCButtonDelegate>

@property(nonatomic,retain)NSArray *colors;

@property(nonatomic,retain)NSArray *sizes;

@property(nonatomic,assign)CGFloat index;

@property(nonatomic,retain)RLCMyButton *btn2;

@property(nonatomic,retain)RLCMyButton *btn3;

@property(nonatomic,retain)RLCMyButton *selButton;

@end

@implementation RLCView
-(instancetype)initWithFrame:(CGRect)frame colors:(NSArray <UIColor *>*)colors  sizes:(NSArray <NSNumber *> *)sizes{
    if (self=[super initWithFrame:frame]) {
        _colors=colors;
        _sizes=sizes;
    }
    return self;
}
-(void)createView{
    _index=10;
    CGRect Farme=CGRectMake(_index, _index, 200-2*_index, 200-2*_index);
    _sizes=@[[NSNumber numberWithInt:130],[NSNumber numberWithInt:250],[NSNumber numberWithInteger:300],[NSNumber numberWithInt:360]];
    _colors=@[[UIColor redColor],[UIColor blueColor],[UIColor yellowColor],[UIColor purpleColor]];
    for (int i=0; i<_sizes.count; i++) {
        RLCMyButton *btn2;
        if (i==0) {
            btn2=[[RLCMyButton alloc]initWithFrame: CGRectMake(25, 25, 150, 150) color: _colors[i] start:0 stop:[ _sizes[i] floatValue]];
        }else{
            btn2=[[RLCMyButton alloc]initWithFrame: CGRectMake(25, 25, 150, 150) color: _colors[i] start:[_sizes[i-1] floatValue] stop:[ _sizes[i]floatValue]];
        }
        btn2.tag=100+i;
        btn2.layer.cornerRadius=100-_index;
        [self addSubview:btn2];
    }
    RLCButton *btn=[[RLCButton alloc]initWithFrame:Farme colors:_colors sizes:_sizes];
    btn.layer.cornerRadius=Farme.size.width/2;
    btn.delegate=self;
    [self addSubview:btn];
    [self shuaxin];
}
-(void)shuaxin{
    RLCMyButton *btn3=[[RLCMyButton alloc]initWithFrame:CGRectMake(0, 0, 200, 200) islink:YES];
    [self addSubview:btn3];
}
-(void)didbutton:(RLCButton *)btn index:(int)index toindex:(int)toindex{
    CGFloat a=1.5;
    RLCMyButton *View1=[self viewWithTag:100+toindex];
    RLCMyButton *View=[self viewWithTag:100+index];
    if (index!=toindex) {
        if (index>=0) {
            [self setView:View frame:CGRectMake(25, 25, 150, 150)];
        }
        [self setView:View1 frame:CGRectMake(a, a, 200-2*a, 200-2*a)];
    }else {
        if (View1.bounds.size.width==50) {
             [self setView:View1 frame:CGRectMake(a, a, 200-2*a, 200-2*a)];
        }else {
           [self setView:View1 frame:CGRectMake(25, 25, 150, 150)];
        }
    }
    _selButton=View1 ;
    if ([self.delegate respondsToSelector:@selector(didcellintdex:)]) {
        [self.delegate didcellintdex:toindex];
    }
}
-(void)setView:(RLCMyButton *)RlcMyButton frame:(CGRect)Frame{
    RlcMyButton.layer.cornerRadius=100-_index;
    [UIView animateWithDuration:0 delay:0.3 usingSpringWithDamping:0.3 initialSpringVelocity:0.7 options:UIViewAnimationOptionOverrideInheritedCurve animations:^{
        RlcMyButton.frame=Frame;
    } completion:^(BOOL finished) {
    }];
}
-(void)stop{
    _selButton.frame=CGRectMake(25, 25, 150, 150);
}



@end
