

#import <UIKit/UIKit.h>

@protocol ViewControllerDelegate <NSObject>

@optional

-(void)didselsctview:(NSString * )str;

@end

@interface ViewController : UIView

@property(nonatomic,retain)NSDictionary *dict;

@property(nonatomic,assign)id <ViewControllerDelegate>delegate;
@end

