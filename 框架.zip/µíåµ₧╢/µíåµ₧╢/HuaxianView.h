//
//  HuaxianView.h
//  个人
//
//  Created by Macintosh HD on 16/7/6.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HuaxianView : UIView

-(instancetype)initWithFrame:(CGRect)frame points:(NSArray <NSString * >*)points;

//折线的颜色
@property(nonatomic,retain)UIColor *lineClocr;
//折线的宽度
@property(nonatomic,assign)CGFloat lineWidth;
//划线的时间
@property(nonatomic,assign)CGFloat linetime;
//X线的个数
@property(nonatomic,assign)CGFloat XSHU;
//X线右边的标间隔数
@property(nonatomic,assign)CGFloat XBiaoshu;
//坐标的线颜色
@property(nonatomic,retain)UIColor *XYColor;
//Y线的个数
@property(nonatomic,assign)CGFloat YSHU;
//Y线的角标间隔数
@property(nonatomic,assign)CGFloat YBiaoshu;
@end
