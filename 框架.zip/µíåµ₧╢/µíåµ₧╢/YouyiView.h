//
//  YouyiView.h
//  框架
//
//  Created by Apple on 16/9/8.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol YouyiViewDelegate <NSObject>

@optional
-(void)jihaoweijinqiu:(int)index;

@end

@interface YouyiView : UIView


@property(nonatomic,assign)id <YouyiViewDelegate> delegate;

-(void)kaishiBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;
/**
 *  检查是不是准备就绪了
 *
 *  @return <#return value description#>
 */
-(BOOL)zhunbeijiuxu;
/**
 *  准备
 */
-(void)zhunbei;
@end
