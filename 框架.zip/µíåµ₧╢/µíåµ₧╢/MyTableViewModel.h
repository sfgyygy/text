//
//  MyTableViewModel.h
//  框架
//
//  Created by Apple on 16/8/18.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "BaseModel.h"

@interface MyTableViewModel : BaseModel

//CELL的高度 默认200
@property(nonatomic,assign)float CELL_H;

@end
