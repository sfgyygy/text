

#import "UILabel+MyHelpr.h"

@implementation UILabel (MyHelpr)

static int donghua;

__strong UILabel * donghuaLabel;

-(instancetype)initWithFrame:(CGRect)frame text:(nullable  NSString *)text
{
    return  [self initWithFrame:frame text:text textColor:UILABEL_TEXTCOLOR index:UILABEL_INDEX size:UILABEL_SIZE];
}
-(instancetype)initWithFrame:(CGRect)frame text1:(nullable NSString *)text
{
    return  [self initWithFrame:frame text:text textColor:UILABEL_TEXTCOLOR1 index:UILABEL_INDEX size:UILABEL_SIZE1];
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text isdonghua:(BOOL)isdonghua
{
    if (self = [self initWithFrame:frame text:text]) {
        if (isdonghua) {
            donghua = 1 ;
            [self startAnimationIfNeeded];
        }
    }
    return self ;
}

-(instancetype)initWithFrame:(CGRect)frame text:(nullable  NSString *)text textColor:(nullable UIColor *)textColor
{
    return  [self initWithFrame:frame text:text textColor:textColor index:UILABEL_INDEX size:UILABEL_SIZE];
}
-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text size:( CGFloat)size
{
    return  [self initWithFrame:frame text:text textColor:UILABEL_TEXTCOLOR index:UILABEL_INDEX size:size];
}

-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text textColor:(nullable UIColor *)textColor intdex:( int)index
{
    return  [self initWithFrame:frame text:text textColor:textColor index:index size:UILABEL_SIZE];
}

-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text size:(CGFloat)size index:(int)index
{
    return  [self initWithFrame:frame text:text textColor:UILABEL_TEXTCOLOR index:index size:size];
}

-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text textColor:(nullable UIColor *)textColor index:(int)index size:(CGFloat)size
{
    if (self = [self initWithFrame:frame]) {
        self.text = text;
        self.textColor = textColor;
        if (index == 0) {
            self.textAlignment = NSTextAlignmentLeft;
        }else if(index ==1){
            self.textAlignment = NSTextAlignmentCenter;
        }else if(index ==2){
            self.textAlignment = NSTextAlignmentRight;
        }
        self.font = [UIFont systemFontOfSize:size];
    }
    return  self ;
}
-(void)addAttr:(NSString *)str kaiindex:(int)kaiindex kaicolor:(UIColor *)kaicolor  jieindex:(int)jieindex jiecolor:(UIColor *)jiecolor
{
    NSMutableAttributedString  * str1 = [[NSMutableAttributedString alloc]initWithString:str];
    [str1 addAttribute:NSForegroundColorAttributeName value:jiecolor range:NSMakeRange(0, jieindex)];
    [str1 addAttribute:NSForegroundColorAttributeName value:kaicolor range:NSMakeRange(0, kaiindex)];
    [self setAttributedText:str1];
}
-(void)startAnimationIfNeeded{
    [self.layer removeAllAnimations];
    if (donghua != 1) {
        return;
    }
    self.backgroundColor = [UIColor whiteColor];
    float width = [Helpr widthOfString:self.text font:self.font height:self.bounds.size.height];
    const float oriWidth = self.bounds.size.width;
    if (width > oriWidth) {
        if (!donghuaLabel) {
            UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, width, self.bounds.size.height) text:self.text] ;
            label.font = self.font ;
            label.textColor = self.textColor;
            self.clipsToBounds = YES ;
            [self addSubview:label];
            donghuaLabel = label;
            self.textColor = [UIColor clearColor];
        }
     donghuaLabel.frame = CGRectMake(0, 0, width, self.bounds.size.height);
        float offset = width - oriWidth;
        [UIView animateWithDuration:3.0
                              delay:0
                            options:UIViewAnimationOptionRepeat|UIViewAnimationOptionAutoreverse //动画重复的主开关
                         animations:^{
                             donghuaLabel.frame = CGRectMake( -offset  , 0, width, self.bounds.size.height);
                         }
                         completion:^(BOOL finished) {
 
                         }
         ];
    }
}

@end
