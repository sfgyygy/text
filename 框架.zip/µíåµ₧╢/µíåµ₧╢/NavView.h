//
//  NavView.h
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NavViewDelegate <NSObject>

@optional
/**
 *  用户点击返回
 */
-(void)didfanhui;
@end

@interface NavView : UIView

NS_ASSUME_NONNULL_BEGIN
/**
 *  初始化方法
 *
 *  @param frame 位子    h =64
 *  @param title  titlelabel
 *
 *  @return self
 */
-(instancetype)initWithFrame:(CGRect)frame title:(nullable NSString *)title;
/**
 *  代理
 */
@property(nonatomic,assign)id <NavViewDelegate> delegate;
/**
 *  返回Btn
 */
@property(nonatomic,retain)UIButton * fanhuiBtn;
/**
 *  中间的Label
 */
@property(nonatomic,retain)UILabel * titleLabel;
/**
 *  title 名字
 */
@property(nonatomic,copy)NSString * title;
/**
 *  是否有返回按钮  默认有返回
 *
 *  @param isfanhui  bool
 */
-(void)isfanhuiBtn:(BOOL)isfanhui;

NS_ASSUME_NONNULL_END
@end
