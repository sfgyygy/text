


#import <UIKit/UIKit.h>

@interface UIView (Helpr)
NS_ASSUME_NONNULL_BEGIN
/**
 *  自定义view前面的nameLabel 后面＋ view  ＋箭头  背景颜色  默认高度30
 */
@property(nonatomic,retain)UILabel * nametextLabel;

/**
 *  nameLabel 到顶部距离的间隔  4 默认5  别的默认10
 */
@property(nonatomic,assign)CGFloat  nameLabel_h;

/**
 *  快速创建 view  开启用户交互
 *
 *  @param frame   位子
 *  @param bgColor 背景颜色
 *
 *  @return self
 */
-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor;

/**
 *  快速创建 view  开启用户交互  并添加前面label 后面的view  后面是否有箭头  背景颜色
 *
 *  @param frame   位子
 *  @param str     label的text  默认16号字体  字体靠右显示 长度为100
 *  @param bgView  后面的viewe
 *  @param jiantou 是否有左箭头
 *  @bgcolor      背景颜色
 *  @return  self
 */
-(instancetype)initWithFrame:(CGRect)frame str:(nullable NSString *)str view:(nullable UIView *)bgView isjiantou:(BOOL)jiantou bgColor:(UIColor *)bgColor;
/**
 *  添加最下面的线
 *
 *  @param color  线的颜色
 *  @param width  线的开始位子
 *  @param height 线的宽度
 */
-(void)addUnderscoreWihtColor:(UIColor *)color width:(CGFloat)width height:(CGFloat)height;
/**
 *  快速创建 view  开启用户交互  并添加前面label 后面的view  后面图片  背景颜色
 *
 *  @param frame       位子
 *  @param bgColor     背景颜色
 *  @param label       label
 *  @param BgView      view
 *  @param bgImageView imageview
 *
 *  @return self
 */
-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor label:(nullable UILabel *)label view:(nullable UIView * )BgView imageView:(nullable UIImageView *)bgImageView;

NS_ASSUME_NONNULL_END
@end
