//
//  MyTableView.m
//  个人
//
//  Created by Macintosh HD on 16/6/2.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "MyTableView.h"

@interface MyTableView () <MyTableViewCellDelegate>
/**
 *  下载的数据
 */
@property(nonatomic,retain)NSMutableArray *arrayDatas;
/**
 *  tableView
 */
@property (nonatomic, retain) UITableView *tableView;
/**
 *   下载的数据添加地址
 */
@property(nonatomic,copy)NSString *downUrl;
/**
 *  当前下载的页数
 */
@property(nonatomic,assign)int page;
@end

@interface MyTableView ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,assign)int index;
@end

@implementation MyTableView
#pragma mark-----赖加载
-(NSMutableArray *)arrayDatas
{
    if (_arrayDatas == nil) {
        _arrayDatas = [NSMutableArray arrayWithCapacity:10];
    }
    return _arrayDatas;
}
-(void)setCellname:(NSString *)cellname
{
      Class cls = NSClassFromString(cellname);
    if (cls == nil) {
        MyLog(@"%@======没有这个类",cellname);
    }
    _cellname = cellname;
}
-(void)setModel:(NSString *)model
{
     Class cls = NSClassFromString(model);
    if (cls == nil) {
         MyLog(@"%@======没有这个类",model);
    }
    _model = model;
}
-(UIImageView *)BgImageView
{
    if (_BgImageView == nil) {
        _BgImageView = [[UIImageView alloc]initWithFrame:self.bounds image:[UIImage imageNamed:TABLEVIEW_BGIMAGE]];
    }
    return _BgImageView;
}
//设置占位图片
-(void)setBgimage:(UIImage *)Bgimage
{
    _Bgimage = Bgimage;
    self.BgImageView.image = Bgimage;
}
//创建tbaleview
-(instancetype)initWithFrame:(CGRect)frame URL:(NSString *)url cellname:(NSString *)cellname model:(NSString *)model data:(NSString *)data
{
    if (self=[super initWithFrame:frame]) {
        self.cellname=cellname;
        self.model=model;
        self.data=data;
        self.page=1;
        self.url=url;
    }
    return self;
}
#pragma mark-----get请求下载数据
-(void)getdownDatas:(int)index
{
    if (index != 0) {
         _downUrl=[NSString stringWithFormat:@"%@&%@=%d",_url,TABLEVIEW_PAGE,_page ];
    }else{
         _downUrl = _url ;
    }
    MyLog(@"%@",URL(_downUrl));
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:URL(_downUrl) parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        NSLog(@"downloadProgress==%@",downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        [self duxu:responseDict];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"err0r===%@",error);
    }];
}
#pragma mark-----post请求数据
-(void)postownDatas:(int)index dict:(NSDictionary *)dict
{
    if (index != 0) {
        _downUrl=[NSString stringWithFormat:@"%@&%@=%d",_url,TABLEVIEW_PAGE,_page ];
    }else{
        _downUrl = _url ;
    }
    MyLog(@"%@",URL(_downUrl));
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:URL(_downUrl) parameters:dict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        [self duxu:responseDict];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"err0r===%@",error);
    }];
}
#pragma mark-----解析数据
-(void)duxu:(NSDictionary *)dict
{
    if (self.page <= 1) {
        [self.arrayDatas removeAllObjects];
    }
    Class cls = NSClassFromString(self.model);
    NSDictionary   * dict1 =dict;
    NSArray * array ;
    if (self.data1.length > 0) {
        dict1 = [dict objectForKey:self.data];
        array = [dict1 objectForKey:self.data1];
    }else {
        array = [dict1 objectForKeyedSubscript:self.data];
    }
    for (int i = 0; i < array.count; i++) {
        MyTableViewModel  * model2342 = [[cls alloc]initWithDict:array[i]];
        [self.arrayDatas addObject:model2342];
        if (i == 0) {
            MyLog(@"%@",array[i]);
        }
    }
    if (_arrayDatas.count == 0) {
        self.BgImageView.alpha = 1;
    }else {
        self.BgImageView.alpha = 0 ;
    }
    [_tableView reloadData];
    if ([self.delegate respondsToSelector:@selector(getdatasOK)]) {
        [self.delegate getdatasOK];
    }
}

-(void)createTableView:(int)index{
    self.tableView=[[UITableView alloc]initWithFrame:self.bounds style:UITableViewStylePlain];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    //隐藏线  cell 重写线的样式
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.bounces=YES;
    self.tableView.backgroundColor = TABLEVIEW_BGCOLOR;
    if(self.hearView){
        self.tableView.tableHeaderView = self.hearView;
    }
    [self addSubview:self.tableView];

    if (index == 0) {
        return;
    }
    _tableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _page=1;
        [self getdownDatas:index];
        [_tableView.mj_header endRefreshing];
    }];
    _tableView.mj_footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        _page++;
        [self getdownDatas:index];
        [self.tableView.mj_footer endRefreshing];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
       return self.arrayDatas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Class cls = NSClassFromString(_cellname);
    MyTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.row,( long)indexPath.length]];
    if (!cell) {
        cell=[[cls    alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.row,(long)indexPath.length]];
    }
    cell.model=[self getIndexPath:indexPath];
    cell.delegate = self.delegate ;
    return cell;
}

#pragma mark---选TableView的CELL
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    MyTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.row,( long)indexPath.length]];
    MyTableViewModel *model = [self getIndexPath:indexPath];
    if ([self.delegate respondsToSelector:@selector(MytableView:model:cell:)]) {
        [self.delegate MytableView:self model:model cell:cell];
    }
}

#pragma mark----设置TableViewCell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
     MyTableViewModel *model=[self getIndexPath:indexPath];
    return model.CELL_H;
}

#pragma mark---获取MODEL
-(MyTableViewModel *)getIndexPath:(NSIndexPath *)indexPath{
    return self.arrayDatas[indexPath.row];
}
@end
