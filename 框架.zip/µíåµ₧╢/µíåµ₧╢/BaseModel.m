//
//  BaseModel.m
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self=[self init]) {
        self.dict=dict;
    }
    return self;
}
-(void)setDict:(NSDictionary *)dict{
    _dict=dict;
    NSArray *array=[self getAllProperties];
    for (NSString *str in array) {
        if ([self judgewithStr:str]) {
            NSString * str1 = [str stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[str substringToIndex:1] uppercaseString]];
            str1=[NSString stringWithFormat:@"set%@:",str1];
            if([self respondsToSelector:NSSelectorFromString(str1)]){
                IMP imp = [self methodForSelector:NSSelectorFromString(str1)];
                void (*func)(id, SEL,id) = (void *)imp;
                func(self, NSSelectorFromString(str1),[dict objectForKey:str]);
            }else {
              //  MyLog(@"儿子没有这个属性 %@",str1);
            }
        }else {
            MyLog(@"传入字典没有这个属性 %@",str);
        }
    }
}

-(void)remove
{
    NSArray *array=[self getAllProperties];
    for (NSString *str in array) {
        NSString * str1 = [str stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[str substringToIndex:1] uppercaseString]];
        str1=[NSString stringWithFormat:@"set%@:",str1];
        if([self respondsToSelector:NSSelectorFromString(str1)]){
            IMP imp = [self methodForSelector:NSSelectorFromString(str1)];
            void (*func)(id, SEL,id) = (void *)imp;
            func(self, NSSelectorFromString(str1),nil);
        }
    }
}
-(BOOL)judgewithStr:(NSString *)str{
    for (NSString *str1 in self.dict.allKeys) {
        if ([str isEqualToString:str1]) {
            if ([self.dict[str1] class] == [NSNull class]) {
                [self.dict setValue:@"" forKey:str1 ];
            }
            return  YES;
        }
    }
    return NO;
}


@end
