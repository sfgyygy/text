//
//  UIButton+Helpr.m
//  个人
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "UIButton+Helpr.h"

@implementation UIButton (Helpr)

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text id:(id)delegate sel:(SEL)sel{
    return  [self initWithFrame:frame text:text size:UIBUTTON_SIZE textColor:UIBUTTON_TEXTCOLOR beijingColor:UIBUTTON_BEIJINGCOLOR cornerRadius:0 id:delegate sel:sel];
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size id:(id)delegate sel:(SEL)sel{
        return  [self initWithFrame:frame text:text size:size textColor:UIBUTTON_TEXTCOLOR beijingColor:UIBUTTON_BEIJINGCOLOR cornerRadius:0 id:delegate sel:sel];
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text  textColor:(nullable UIColor *)textColor id:(id)delegate sel:(SEL)sel{
        return  [self initWithFrame:frame text:text size:UIBUTTON_SIZE textColor:textColor beijingColor:UIBUTTON_BEIJINGCOLOR cornerRadius:0 id:delegate sel:sel];
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text  size:(CGFloat)size textColor:(nullable UIColor *)textColor id:(id)delegate sel:(SEL)sel{
        return  [self initWithFrame:frame text:text size:size textColor:textColor beijingColor:UIBUTTON_BEIJINGCOLOR cornerRadius:0 id:delegate sel:sel];
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size textColor:(UIColor *)textColor beijingColor:(UIColor *)bejingColor  cornerRadius:(CGFloat)cornerRadius id:(id)delegate sel:(SEL)sel{
    if (self = [self initWithFrame:frame]) {
        [self setTitle:text forState:0];
        [self setTitleColor:textColor forState:0];
        [self setBackgroundColor:bejingColor];
        self.titleLabel.font = [UIFont systemFontOfSize:size];
        self.layer.cornerRadius = cornerRadius;
        [self addTarget:delegate action:sel forControlEvents:UIControlEventTouchUpInside];
    }
    return self ;
}

-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)size textColor:(UIColor *)textColor beijingColor:(UIColor *)bejingColor  biankuangColor:(nullable UIColor *)biankuangColor cornerRadius:(CGFloat)cornerRadius id:(id)delegate sel:(SEL)sel
{
    if (self = [self initWithFrame:frame text:text size:size textColor:textColor beijingColor:bejingColor cornerRadius:cornerRadius id:delegate sel:sel] ) {
        if (!biankuangColor) {
            biankuangColor = UIBUTTON_BIANKUANGCOLOR;
        }
        [self.layer setBorderColor:biankuangColor.CGColor];
        [self.layer setBorderWidth:UIBUTTON_BIANKUANGSIZE];
    }
    return self;
}
-(instancetype)initWithFrame:(CGRect)frame backImage:(UIImage *)backImage id:(id)delegate sel:(SEL)sel
{
    if (self = [self initWithFrame:frame]) {
        if (backImage) {
            [self setBackgroundImage:backImage forState:0];
        }else{
            [self setBackgroundImage:[UIImage imageNamed:UIBUTTON_BACKIMAGENAME] forState:0];
        }
        [self addTarget:delegate action:sel forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

-(void)setBackgroundImage:(nullable UIImage *)image withUrl:(NSString *)url{
    //添加
    __block  UIActivityIndicatorView * activ=[UIImage downloadingImageActivityIndicatorView:CGRectMake(self.bounds.size.width/2-5,self.bounds.size.height/2-5 , 10, 10)];
    [self addSubview:activ];
    if (!self.currentBackgroundImage) {
        if (image) {
            [self setBackgroundImage:image forState:0];
        }else {
            [self setBackgroundImage:[UIImage imageNamed:UIBUTTON_BACKIMAGENAME] forState:0];
        }
    }else {
        dispatch_queue_t queue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(queue, ^{
            UIImage *image=[UIImage setimageWithURL:url];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (image != nil) {
                    [self setBackgroundImage:image forState:0];
                }else {
                    //设置下载失败的破土
                     [self setBackgroundImage:[UIImage imageNamed:IMAGE_XIAZAISHIBAI] forState:0];
                }
                [activ removeFromSuperview];
            });
        });
    }
}
-(void)setBackgroundWithUrl:(NSString *)url{
    [self setBackgroundImage:[UIImage imageNamed:UIBUTTON_BACKIMAGENAME] forState:0];
}

-(void)addAttr:(NSString *)str kaiindex:(int)kaiindex kaicolor:(UIColor *)kaicolor  jieindex:(int)jieindex jiecolor:(UIColor *)jiecolor
{
    NSMutableAttributedString  * str1 = [[NSMutableAttributedString alloc]initWithString:str];
    [str1 addAttribute:NSForegroundColorAttributeName value:jiecolor range:NSMakeRange(0, jieindex)];
    [str1 addAttribute:NSForegroundColorAttributeName value:kaicolor range:NSMakeRange(0, kaiindex)];
    [self.titleLabel setAttributedText:str1];
}

@end

/**
 *  这个验证码的按钮
 */
@interface YanzhenButton ()

@property(nonatomic,assign)int index;

@end

@implementation YanzhenButton

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self.layer setBorderWidth:1];
        [self.layer setBorderColor:YANZHENBTN_BIANKUANGCOLOR.CGColor];
        [self setBackgroundColor:YANZHENBTN_BEIJINGCOLOR];
        [self setTintColor:YANZHENGBTN_TITTECOLOR];
        [self.titleLabel setFont:[UIFont systemFontOfSize:YANZHENBTN_TITSIZE]];
    }
    return self;
}


-(void)openTimer{
    if (!self.timer) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
    }
    [self.timer setFireDate:[NSDate distantPast]];
    if (!self.time) {
        _index = 60;
    }else
    {
        _index = self.time;
    }
    self.userInteractionEnabled = NO;
}

-(void)stopTimer
{
    self.userInteractionEnabled = YES;
    [self.timer setFireDate:[NSDate distantFuture]];
    [self setTitle:@"重新获取" forState:0];
}

-(void)updateTimer
{
    NSString * str1;
    if (_index > 0) {
        str1=[NSString stringWithFormat:@"%02dS",_index];
        _index--;
    }else
    {
        str1=@"重新获取";
        self.userInteractionEnabled = YES;
        [self.timer setFireDate:[NSDate distantFuture]];
    }
    [self setTitle:str1 forState:0];
}
@end

