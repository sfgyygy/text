//
//  MainTabBarViewController.h
//  XM
//
//  Created by Macintosh HD on 16/4/16.
//  Copyright © 2016年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "MainTabBarViewController.h"
#import "MyTabBar.h"
#import "MainNavigrtionController.h"

@interface MainTabBarViewController : UITabBarController

@property (nonatomic, copy)NSString *Plostname;

@property (nonatomic, retain) NSArray *arrayPlist;

-(instancetype)initWithStringPlist:(NSString *)Plist;

- (void)createViewControllers;

-(instancetype)initWithStringPlist:(NSString *)Plist userid:(NSString *)userid;

@end
