//
//  AppDelegate.h
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainTabBarViewController.h"
#import "MainNavigrtionController.h"
#import "NewFeatureViewController.h"
#import "DengluViewController.h"


#import "BanbenGengxin.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

