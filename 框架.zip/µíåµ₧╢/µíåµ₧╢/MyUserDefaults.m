



#import "MyUserDefaults.h"

@implementation MyUserDefaults
XMGSingletoM
//保存值
-(void)setObject:(nullable id)value forKey:(NSString *)defaultName
{
    NSUserDefaults *df = [NSUserDefaults standardUserDefaults];
    [df setObject:value forKey:defaultName];
    [df synchronize];
}
//取值
-(nullable id)objectForKey:(NSString *)defaultName
{
    NSUserDefaults *df = [NSUserDefaults standardUserDefaults];
    return  [df objectForKey:defaultName];
}

-(void)removeKey:(NSString *)defaultName{
    NSUserDefaults *df = [NSUserDefaults standardUserDefaults];
    [df removeObjectForKey:defaultName];
    [df synchronize];
}
@end
