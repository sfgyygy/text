
#import <UIKit/UIKit.h>

@protocol RLCViewDelegate <NSObject>

@optional

-(void)didcellintdex:(int)index;

@end

@interface RLCView : UIView
@property(nonatomic,assign)id<RLCViewDelegate>delegate;

-(instancetype)initWithFrame:(CGRect)frame colors:(NSArray <UIColor *>*)colors  sizes:(NSArray <NSNumber *> *)sizes;

-(void)createView;

-(void)shuaxin;

-(void)stop;


@end
