//
//  UIView+Helpr.m
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "UIView+Helpr.h"
@implementation UIView (Helpr)

@dynamic nametextLabel;
@dynamic nameLabel_h;
__strong UILabel * _nametextLabel;

-(UILabel *)nametextLabel
{
    if (_nametextLabel == nil) {
        _nametextLabel = [[UILabel alloc]init];
    }
    return _nametextLabel;
}
-(void)setNametextLabel:(UILabel *)nametextLabel
{
    _nametextLabel = nametextLabel;
}
-(CGFloat)nameLabel_h
{
    if (isIPhone4) {
        return 5;
    }else {
        return  10;
    }
}
//快速创建view
-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor
{
    if (self = [self initWithFrame:frame]) {
        self.backgroundColor = bgColor;
        self.userInteractionEnabled = YES;
    }
    return self;
}
//快速创建自定义view
-(instancetype)initWithFrame:(CGRect)frame str:(NSString *)str view:(UIView *)bgView isjiantou:(BOOL)jiantou bgColor:(UIColor *)bgColor
{
    if (self= [self initWithFrame:frame bgColor:bgColor]) {
        //添加namelabel
        self.nametextLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, self.nameLabel_h,[self widthOfString:str font:[UIFont systemFontOfSize:NAMELABEL_TEXTSIZI(16)] height:30] , 30)];
        self.nametextLabel.text = str;
        self.nametextLabel.textAlignment = NSTextAlignmentLeft;
        self.nametextLabel.textColor = NAMELABEL_TEXTCOLOR;
        self.nametextLabel.font = [UIFont systemFontOfSize:NAMELABEL_TEXTSIZI(16)];
        [self addSubview:self.nametextLabel];
        if (bgView){
        [self addSubview:bgView];
        }
        if (jiantou) {
            UIImageView * iamgeView = [[UIImageView alloc]initWithFrame:CGRectMake(self.bounds.size.width - 30, self.bounds.size.height / 2 - 10 , 10, 20)];
            iamgeView.image = [UIImage imageNamed:IMAGEVIEW_ZUOJIANTOUNAME2];
            [self addSubview:iamgeView];
        }
    }
    return self;
}
//计算宽度
-(CGFloat)widthOfString:(NSString *)string font:(UIFont *)font height:(CGFloat)height
{
    NSDictionary * dict=[NSDictionary dictionaryWithObject: font forKey:NSFontAttributeName];
    CGRect rect=[string boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, height) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil];
    return rect.size.width;
}
//添加下划线
-(void)addUnderscoreWihtColor:(UIColor *)color width:(CGFloat)width height:(CGFloat)height
{
    UIView * xian = [[UIView alloc]initWithFrame:CGRectMake(width, self.bounds.size.height - height, self.bounds.size.width - width * 2, height)];
    xian.backgroundColor = color;
    [self addSubview:xian];
}
// 快速创建自定义view
-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor label:(nullable UILabel *)label view:(nullable UIView * )BgView imageView:(nullable UIImageView *)bgImageView
{
    if (self = [self initWithFrame:frame bgColor:bgColor]) {
        [self addSubview:label];
        [self addSubview:BgView];
        [self addSubview:bgImageView];
    }
    return  self ;
}

@end
