

#import <UIKit/UIKit.h>

@interface UILabel (MyHelpr)
NS_ASSUME_NONNULL_BEGIN
/****
 位子 文字  默认字体0 颜色0
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable  NSString *)text;
/**
 *  <#Description#>
 *
 *  @param frame 位子
 *  @param text  text
 *
 *  @return 默认字体大小1 颜色1
 */
-(instancetype)initWithFrame:(CGRect)frame text1:(nullable NSString *)text;
/**
 *  位子长度大于返回 添加动画
 *
 *  @param frame
 *  @param text
 *  @param isdonghua
 *
 *  @return
 */
-(instancetype)initWithFrame:(CGRect)frame text:(NSString *)text isdonghua:(BOOL)isdonghua;
/****
 位子 文字 颜色
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable  NSString *)text textColor:(nullable UIColor *)textColor;
/****
 位子 文字 大小
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text size:( CGFloat)size;
/****
 位子 文字  颜色  大小
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text textColor:(nullable UIColor *)textColor intdex:( int)index;
/****
 位子 文字 大小 位子
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text size:(CGFloat)size index:(int)index;
/****
 位子 文字  颜色 大小 位子
 */
-(instancetype)initWithFrame:(CGRect)frame text:(nullable NSString *)text textColor:(nullable UIColor *)textColor index:(int)index size:(CGFloat)size;
/**
 *  设置uilabel的文字颜色不一样
 *
 *  @param str      内容
 *  @param kaiindex 第1段内容的介绍下标
 *  @param kaicolor 第1段内容的颜色
 *  @param jieindex 第2段内容的介绍下表
 *  @param jiecolor 第2段内容的颜色
 */
-(void)addAttr:(NSString *)str kaiindex:(int)kaiindex kaicolor:(UIColor *)kaicolor  jieindex:(int)jieindex jiecolor:(UIColor *)jiecolor;
/**
 *  文字滚动
 */
-(void)startAnimationIfNeeded;

NS_ASSUME_NONNULL_END
@end
