//
//  UITextField+Helpr.h
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Helpr)
/**
 *  普通输入框
 *
 *  @param fram        位子
 *  @param pliceholder 显示文字
 *  @param borderStyle 类型
 *
 *  @return self
 */
-(instancetype)initWithfram:(CGRect)fram placeholder:(NSString *)placeholder borderStyle:(UITextBorderStyle )borderStyle;
/**
 *  密码输入框
 *
 *  @param fram        位子
 *  @param pliceholder 文字
 *  @param borderStyle 类型
 *
 *  @return self
 */
-(instancetype)initWithfram:(CGRect)fram mimaplaceholder:(NSString *)placeholder borderStyle:(UITextBorderStyle )borderStyle;

@end
