
#import <UIKit/UIKit.h>

@interface RLCMyButton : UIButton

-(instancetype)initWithFrame:(CGRect)frame color:(UIColor *)color  start:(CGFloat)startindex stop:(CGFloat)stopindex;

-(instancetype)initWithFrame:(CGRect)frame islink:(BOOL)link;

@end
