





#import "BaseModel.h"
#import "MyUserDefaults.h"

@interface GerenModel : BaseModel

XMGSingletoH

@property(nonatomic,copy)NSString * userid;

@property(nonatomic,copy)NSString * username;

@property(nonatomic,copy)NSString * userpassword;

@property(nonatomic,copy)NSString * sid;

/**
 *  保存当前数据
 */
-(void)saveGerenModel;
/**
 *  删除保存的数据
 */
-(void)removeGereModel;
/**
 *  读取保存的数据
 */
-(void)readGerenModel;
/**
 *  验证当前帐号密码
 */
-(void)validationuserid;
@end
