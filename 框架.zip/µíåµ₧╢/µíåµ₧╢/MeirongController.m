//
//  MeirongController.m
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "MeirongController.h"


@interface MeirongController ()


@property(nonatomic,retain)NSArray * nameArray;

@property(nonatomic,retain)NSArray  <NSString *>* controllerArray;

@end

@implementation MeirongController

-(NSArray *)nameArray
{
    if (_nameArray == nil) {
        _nameArray = @[@"游戏1",@"游戏2"];
    }
    return _nameArray;
}

-(NSArray *)controllerArray
{
    if (_controllerArray == nil) {
        _controllerArray = @[@"YouyiController",@"YouerController"];
    }
    return _controllerArray;
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    [self createView];
}
-(void)createView
{
    CGFloat f = 65;
    for (int i = 0 ; i < self.nameArray.count ; i++) {
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(10, f + 50 * i, SCREEN_WIDTH - 20, 50) text:self.nameArray[i] id:self sel:@selector(Click:)];
        btn.tag = 100 + i ;
        [btn addUnderscoreWihtColor:[UIColor blueColor] width:-10 height:1];
        [self.view addSubview:btn];
    }
}
-(void)Click:(UIButton *)btn
{
    [self popControllerwithstr:self.controllerArray[btn.tag - 100] title:self.nameArray[btn.tag -100]];
    //    Class cls =  NSClassFromString(self.controllerArray[btn.tag - 100]);
    //    BaseViewController * vc = [[cls alloc]initWithNavTitle:self.nameArray[btn.tag - 100]];
    //    TUICHU_XINSHITU(vc);
}
@end
