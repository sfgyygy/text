

#import <UIKit/UIKit.h>

@interface PhotoViewController : UIView

@property (nonatomic,copy)NSString *imageName;

@property (nonatomic,assign)NSInteger currentPage;

@end
