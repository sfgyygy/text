

#import "CustomPlayerView.h"

@implementation CustomPlayerView

+ (Class)layerClass
{
    return [AVPlayerLayer class];
}

//重写player的set方法
-(void)setPlayer:(AVPlayer *)player
{
    _player = player;
    
    //拿到当前view的layer（AVPlayerLayer）
    AVPlayerLayer *layer = (AVPlayerLayer *)self.layer;
    
    //把外部传入的player 添加到layer上
    layer.player = player;
}

@end
