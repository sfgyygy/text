

//屏幕的宽 高

#define UIBUTTON_FANHUIIMAGE   @"turn-arrow"           //返回图片
#define NAVVIEW_BACKCOLOR      RGB_R(231, 232, 234)    //背景颜色

#import "NavView.h"

@implementation NavView

-(instancetype)initWithFrame:(CGRect)frame title:(nullable NSString *)title
{
    if (self = [super initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 64)]) {
        self.title = title;
        [self createView];
        self.backgroundColor = NAVVIEW_BACKCOLOR;
        self.userInteractionEnabled = YES ;
    }
    return  self;
}
-(void)createView{
    //添加文字
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 27, SCREEN_WIDTH, 30)];
    label.text = _title;
    label.font = [UIFont systemFontOfSize:18];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    _titleLabel = label ;
    [self addSubview:_titleLabel];
    //添加返回
    self.fanhuiBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    self.fanhuiBtn.frame = CGRectMake(0, 20, 104, 44);
    [self.fanhuiBtn addTarget:self action:@selector(BtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.fanhuiBtn];
    //返回的图片
    UIImageView * imageview =[[UIImageView alloc]initWithFrame:CGRectMake(20, 10, 15, 24) image:[UIImage imageNamed:UIBUTTON_FANHUIIMAGE] ];
    imageview.userInteractionEnabled = NO;
    [self.fanhuiBtn addSubview:imageview];
}
-(void)isfanhuiBtn:(BOOL)isfanhui
{
    if (!isfanhui) {
        self.fanhuiBtn.alpha = 0;
    }else {
        self.fanhuiBtn.alpha = 1;
    }
}
-(void)BtnClick
{
    if ([self.delegate respondsToSelector:@selector(didfanhui)]) {
        [self.delegate didfanhui];
    }else {
        MyLog(@"代理呢?");
    }
}
@end
