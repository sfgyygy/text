//
//  MoxingController.m
//  个人
//
//  Created by Macintosh HD on 16/6/29.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "MoxingController.h"
#import "RLCView.h"

@interface MoxingController () <RLCViewDelegate>

@property(nonatomic,retain)RLCView *RlcView;

@property(nonatomic,retain)NSArray <UIColor *> *colors;

@property(nonatomic,retain)NSArray <NSNumber *> *Sizes;

@property(nonatomic,retain)UILabel *Label;
@end

@implementation MoxingController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.view.backgroundColor=[UIColor whiteColor];
    [_RlcView shuaxin];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_RlcView stop];
}
-(void)viewDidLoad{
    [super viewDidLoad];
    _colors=@[[UIColor redColor],[UIColor blueColor],[UIColor yellowColor],[UIColor purpleColor]];
    _Sizes=@[[NSNumber numberWithInt:130],[NSNumber numberWithInt:250],[NSNumber numberWithInteger:300],[NSNumber numberWithInt:360]];
    
    RLCView *btn4 = [[RLCView alloc]initWithFrame:CGRectMake(50, 100, 250, 250) colors:_colors sizes:_Sizes];
    btn4.delegate = self;
    [self.view addSubview:btn4];
    [btn4 createView];
    _RlcView=btn4;
    
    _Label=[[UILabel alloc]initWithFrame:CGRectMake(50, 400, 300, 30)];
    _Label.text=@"请点击扇形";
    [self.view addSubview:_Label];
}
-(void)didcellintdex:(int)index{
    _Label.textColor=_colors[index];
    CGFloat a=0;
    if (index==0) {
        a=[_Sizes[index]intValue]/360.0000;
    }else {
        a=([_Sizes[index]intValue]-[_Sizes[index-1]intValue])/360.0000;
    }
    _Label.text=[NSString stringWithFormat:@"第%d个被点击了,比例是%f%@",index,a*100,@"%"];
}
@end
