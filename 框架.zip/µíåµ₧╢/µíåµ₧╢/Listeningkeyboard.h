//
//  Listeningkeyboard.h
//  框架
//
//  Created by Apple on 16/9/1.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^keyboardWillShow)(CGFloat h);

typedef void (^keyboardWillHide)();

@interface Listeningkeyboard : NSObject
/**
 *  移除监听键盘
 */
-(void)stoplistening;
/**
 *
 *
 *  @param boardWillShow 键盘起来
 *  @param boardWillHide 键盘下去
 */
-(void)startlisteningblockcompletion:(keyboardWillShow)boardWillShow keyboard:(keyboardWillHide)boardWillHide;

@property(nonatomic,strong)keyboardWillShow boardWillShow;

@property(nonatomic,strong)keyboardWillHide boardWillHide;

@end
