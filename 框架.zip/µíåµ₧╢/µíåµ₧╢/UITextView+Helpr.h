//
//  UITextView+Helpr.h
//  框架
//
//  Created by Apple on 16/9/2.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (Helpr)

-(instancetype)initWithfram:(CGRect)fram placeholder:(NSString *)placeholder;

@property(nonatomic,copy)NSString * placeholder;

@end
