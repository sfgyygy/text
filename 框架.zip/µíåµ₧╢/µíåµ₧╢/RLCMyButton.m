
#import "RLCMyButton.h"

@interface RLCMyButton ()

@property(nonatomic,retain)UIColor *bgColor;

@property(nonatomic,assign)CGFloat startindex;

@property(nonatomic,assign)CGFloat stopindex;

@property(nonatomic,assign)CGFloat www;

@property(nonatomic,assign)BOOL isClick;

@property (nonatomic, strong) CADisplayLink *link;
@end

@implementation RLCMyButton
-(instancetype)initWithFrame:(CGRect)frame color:(UIColor *)color  start:(CGFloat)startindex stop:(CGFloat)stopindex{
    if (self=[super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.width)]) {
        _bgColor = color;
        _startindex = startindex;
        _stopindex = stopindex;
        _www=frame.size.width;
        _isClick=NO;
    }
    return self;
}
-(instancetype)initWithFrame:(CGRect)frame islink:(BOOL)link{
    if (self=[super initWithFrame:frame]) {
        _bgColor=[UIColor whiteColor];
        _stopindex = 360;
        _startindex = 1;
        _www=frame.size.width;
        _isClick=YES;
        self.link.paused = NO;
        
    }
    return self;
}

- (CADisplayLink *)link{
    if (_link == nil) {
        _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(angleChange)];
        [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    }
    return _link;
}

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 0);
    CGContextSetFillColorWithColor(context, _bgColor.CGColor);
    CGContextMoveToPoint(context, _www/2, _www/2);
    if (_isClick==NO) {
        CGContextAddArc(context, _www/2, _www/2, _www/2,  _startindex* M_PI / 180, _stopindex* M_PI / 180, 0);
        self.clipsToBounds=NO;
    }else {
        CGContextAddArc(context, _www/2, _www/2, _www/2,  _startindex* M_PI / 180,2 * M_PI , 0);
    }
    CGContextClosePath(context);
    CGContextDrawPath(context, kCGPathFillStroke);
}
-(void)angleChange{
        _startindex += 3;
        if (_startindex >= 360) {
            self.link.paused = YES;
            self.alpha = 0;
        }
     [self setNeedsDisplay];
}
@end
