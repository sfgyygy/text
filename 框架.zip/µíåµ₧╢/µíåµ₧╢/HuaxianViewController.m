//
//  HuaxianViewController.m
//  个人
//
//  Created by Macintosh HD on 16/7/6.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "HuaxianViewController.h"

@interface HuaxianViewController () <UITextFieldDelegate>

@property(nonatomic,retain)UIButton *ChonghuaBtn;

@property(nonatomic,retain)UITextField *XSHUText;

@property(nonatomic,retain)UITextField *YShuText;

@property(nonatomic,retain)UITextField *XBiaoshu;

@property(nonatomic,retain)UITextField *YBiaoshu;

@property(nonatomic,retain)UIScrollView *MyScrollView;

@end

@implementation HuaxianViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    UIScrollView *scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 65, SCREEN_WIDTH, SCREEN_HEIGHT - 65)];
    scrollView.contentSize=CGSizeMake(SCREEN_WIDTH,650);
    scrollView.bounces=NO;
    [self.view addSubview:scrollView];
    

    _MyScrollView=scrollView;
    CGPoint aPoints[6];
    aPoints[0]=CGPointMake(0, 0);
    aPoints[1] =CGPointMake(5, 26);//坐标1
    aPoints[2] =CGPointMake(10, 25);//坐标2
    aPoints[3] =CGPointMake(15, 33);//坐标2
    aPoints[4] =CGPointMake(20, 40);//坐标2
    aPoints[5] =CGPointMake(30, 35);//坐标2
    
    NSArray *arrayDatas=@[NSStringFromCGPoint(aPoints[0]),NSStringFromCGPoint(aPoints[1]),NSStringFromCGPoint(aPoints[2]),NSStringFromCGPoint(aPoints[3]),NSStringFromCGPoint(aPoints[4]),NSStringFromCGPoint(aPoints[5])];
 
    _huaxianView=[[HuaxianView alloc]initWithFrame:CGRectMake(10, 30 ,self.view.bounds.size.width-20, 300)points:arrayDatas];
    _huaxianView.backgroundColor=[UIColor whiteColor];
    _huaxianView.XSHU=6;
    _huaxianView.YSHU=8;
    _huaxianView.XYColor=[UIColor groupTableViewBackgroundColor];
    _huaxianView.XBiaoshu=5;
    _huaxianView.YBiaoshu=10;
    [_MyScrollView addSubview:_huaxianView]; 
    NSArray *textArray=@[@"横向行数",@"横向间隔",@"竖向行数",@"竖向间隔"];
    for (int i=0; i<4; i++) {
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(20, 420+50*i - 65, 100, 30) text:textArray[i]];
        [_MyScrollView addSubview:label];
    }
    
    _XSHUText=[Helpr TextFieldWithfram:CGRectMake(120, 420 - 65, 100, 30) pliceholder:@"1-10" borderStyle:UITextBorderStyleNone];
    _XSHUText.keyboardType = UIKeyboardTypeNumberPad;
    [_MyScrollView addSubview:_XSHUText];
    
    _XBiaoshu=[Helpr TextFieldWithfram:CGRectMake(120, 570 - 65, 100, 30) pliceholder:@"1-20" borderStyle:UITextBorderStyleNone];
     _XBiaoshu.keyboardType = UIKeyboardTypeNumberPad;
    [_MyScrollView addSubview:_XBiaoshu];
    
    _YShuText=[Helpr TextFieldWithfram:CGRectMake(120, 520 - 65, 100, 30) pliceholder:@"1-10" borderStyle:UITextBorderStyleNone];
     _YShuText.keyboardType = UIKeyboardTypeNumberPad;
    [_MyScrollView addSubview:_YShuText];
    
    _YBiaoshu=[Helpr TextFieldWithfram:CGRectMake(120, 470 - 65, 100, 30) pliceholder:@"1-20" borderStyle:UITextBorderStyleNone];
     _YBiaoshu.keyboardType = UIKeyboardTypeNumberPad;
    [_MyScrollView addSubview:_YBiaoshu];
    
    _ChonghuaBtn = [[UIButton alloc]initWithFrame:CGRectMake(20, 420+50*4  - 65, 80, 40) text:@"重画" id:self sel:@selector(xian)];
    [_MyScrollView addSubview:_ChonghuaBtn];
    
    _XBiaoshu.delegate=self;
    _XSHUText.delegate=self;
    _YBiaoshu.delegate=self;
    _YShuText.delegate=self;
    
    [self viewLoad];
}

-(void)xian{
    [self downKeyboardHide];
    int a=[_XSHUText.text intValue];
    if (a>2&&a<10) {
        _huaxianView.XSHU=a;
    }
    CGFloat f=[_XBiaoshu.text floatValue];
    if (f>2.5&&f<7.0) {
        _huaxianView.XBiaoshu=f;
    }
    a=[_YShuText.text intValue];
    if (a>2&&a<13) {
        _huaxianView.YSHU=a;
    }
    f=[_YBiaoshu.text floatValue];
    if (f>2.5&&f<15.0) {
        _huaxianView.YBiaoshu=f;
    }
    [_huaxianView  setNeedsDisplay];
}

- (void)viewLoad  {
    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    //增加监听，当键退出时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}
//当键盘出现或改变时调用
- (void)keyboardWillShow:(NSNotification *)aNotification{
    //获取键盘的高度
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    CGFloat height=keyboardRect.size.height;
    _MyScrollView.frame=CGRectMake(0, 65, SCREEN_WIDTH, SCREEN_HEIGHT-height-65);
}
//当键退出时调用
- (void)keyboardWillHide:(NSNotification *)aNotification{
    _MyScrollView.frame=CGRectMake(0, 65, SCREEN_WIDTH, SCREEN_HEIGHT - 65);
}
//手动键盘消失
-(void)downKeyboardHide {
    [_YBiaoshu resignFirstResponder];
    [_YShuText resignFirstResponder];
    [_XBiaoshu resignFirstResponder];
    [_XSHUText resignFirstResponder];    
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
     [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self downKeyboardHide];
    return YES;
}
@end
