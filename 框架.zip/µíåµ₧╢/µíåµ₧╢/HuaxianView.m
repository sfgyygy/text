
#define XCHUSHIINT 50     //XY的初始位子
#define YCHUSHIINT 50
#define XCHUSHIXINX 20

#define HUABIWIDTH 3       //画笔的宽度
#define HUABICOLOR [UIColor redColor] //画笔的颜色
#define LINEDONGHUA 3            //动画的时长
#import "HuaxianView.h"

@interface HuaxianView ()

@property(nonatomic,retain)NSArray *points;
//画笔
@property(nonatomic,assign)CGContextRef context;
//动画的layer
@property(nonatomic,strong)CALayer *xylayer;

@end
@implementation HuaxianView
//初始化并设置一些初始数据
-(instancetype)initWithFrame:(CGRect)frame points:(NSArray<NSString *> *)points{
    if (self=[super initWithFrame:frame]) {
        //解析Ponits
        self.points=points;
        self.clipsToBounds=YES;
        //初始化画笔的颜色 宽度  速度
        _lineWidth=HUABIWIDTH; _lineClocr=HUABICOLOR; _linetime=LINEDONGHUA;
        self.XSHU=0;
        self.layer.shouldRasterize = YES;
    }
    return self;
}

-(void)drawRect:(CGRect)rect{
    _context=UIGraphicsGetCurrentContext();
     //画线
    [self xian];
    [self drawXian];
    [self donghua];
    //画X Y
    [self drawXY];
}
-(void)drawXY{
    if (self.XSHU<=0) {
        return;
    }
    CGFloat xw=self.bounds.size.width-XCHUSHIINT;  //画板X的总宽度
    CGFloat yh=self.bounds.size.height-YCHUSHIINT;  //画板Y的总高度
    CALayer *xylayer=[CALayer layer];
    xylayer.bounds=CGRectMake(0, 0, xw, yh);
    xylayer.position=CGPointMake(XCHUSHIINT, 0);
    xylayer.anchorPoint=CGPointMake(0, 0);
    [self.layer addSublayer:xylayer];
    NSString *str;
    UIFont *font=[UIFont systemFontOfSize:10];
    for (int i=1; i<=_XSHU; i++) {
        //画横线
//        CALayer *layer=[CALayer layer];
//        layer.frame=CGRectMake(0, yh/_XSHU*i, xw-XCHUSHIXINX, 1);
//        layer.backgroundColor=_XYColor.CGColor;
       // [xylayer addSublayer:layer];
        str=[NSString stringWithFormat:@"%.2f",(_XSHU-i)*self.YBiaoshu];
        CGFloat W=[Helpr widthOfString:str font:font height:13];
        //画X的角标
        CGContextSetRGBFillColor (_context,  0, 0, 0, 1.0);//设置填充颜色
        [str drawInRect:CGRectMake(XCHUSHIINT-W-5,  yh/_XSHU*i-5, W, 13) withAttributes:@{NSFontAttributeName:font, NSParagraphStyleAttributeName: [[NSMutableParagraphStyle defaultParagraphStyle] mutableCopy]}];
    }
    //画竖线
    for (int i=0; i<_YSHU; i++) {
//        CALayer *layer=[CALayer layer];
//        layer.frame=CGRectMake(xw/_YSHU*i, 10, 1, yh-10);
//        layer.backgroundColor=_XYColor.CGColor;
       // [xylayer addSublayer:layer];
        if (i>0) {
            CGContextSetRGBFillColor (_context,  0, 0, 0, 1.0);//设置填充颜色
            str=[NSString stringWithFormat:@"%.2f",i*self.XBiaoshu];
            CGFloat W=[Helpr widthOfString:str font:font height:13];
            [str drawInRect:CGRectMake(xw/_YSHU*(i+1),  yh+5, W, 13) withAttributes:@{NSFontAttributeName:font, NSParagraphStyleAttributeName: [[NSMutableParagraphStyle defaultParagraphStyle] mutableCopy]}];
        }
    }
    _xylayer=xylayer;
}
-(void)xian{
    CGFloat xw=self.bounds.size.width-XCHUSHIINT;
    CGFloat yh=self.bounds.size.height-YCHUSHIINT;
    CGFloat a1=CGColorGetComponents(self.XYColor.CGColor)[0];
    CGFloat b1=CGColorGetComponents(self.XYColor.CGColor)[1];
    CGFloat c1=CGColorGetComponents(self.XYColor.CGColor)[2];
    //设置画笔颜色
    CGContextSetRGBStrokeColor(_context,a1,b1,c1,1.0);
    //设置画笔的宽度
    CGContextSetLineWidth(_context, 1);
    for (int i=1; i<=_XSHU; i++) {
        CGPoint apoints[2];
        apoints[0]=CGPointMake(XCHUSHIINT, yh/_XSHU*i);
        apoints[1]=CGPointMake(self.bounds.size.width, yh/_XSHU*i);
        CGContextAddLines(_context, apoints, 2);//添加线
        CGContextDrawPath(_context, kCGPathStroke);
    }
    for (int i=0; i<_YSHU; i++) {
        CGPoint apoints[2];
        apoints[0]=CGPointMake(xw/_YSHU*i+XCHUSHIINT, 0);
        apoints[1]=CGPointMake(xw/_YSHU*i+XCHUSHIINT, yh);
        CGContextAddLines(_context, apoints, 2);//添加线
        CGContextDrawPath(_context, kCGPathStroke);
    }
}
-(void)drawXian{
    CGPoint apoints[_points.count];
    for (int i=0; i<_points.count; i++) {
        CGPoint point =CGPointFromString(_points[i]);
        CGFloat x= XCHUSHIINT+point.x/self.XBiaoshu*((self.bounds.size.width-XCHUSHIINT)/self.YSHU);
        CGFloat y= self.bounds.size.height-YCHUSHIINT-point.y/self.YBiaoshu*((self.bounds.size.height-YCHUSHIINT)/self.XSHU);
        apoints[i]=CGPointMake(x, y);
    }
    //获取颜色3元色
    CGFloat a=CGColorGetComponents(self.lineClocr.CGColor)[0];
    CGFloat b=CGColorGetComponents(self.lineClocr.CGColor)[1];
    CGFloat c=CGColorGetComponents(self.lineClocr.CGColor)[2];
   //设置画笔颜色
    CGContextSetRGBStrokeColor(_context,a,b,c,1.0);
    //设置画笔的宽度
    CGContextSetLineWidth(_context, self.lineWidth);
    CGContextAddLines(_context, apoints, _points.count);//添加线
    CGContextDrawPath(_context, kCGPathStroke);
}
-(void)donghua{
    //添加新的Layer  添加动画
    CAShapeLayer *layer=[CAShapeLayer layer];
    layer.bounds=CGRectMake(XCHUSHIINT, 0, self.bounds.size.width-XCHUSHIINT, self.bounds.size.height-YCHUSHIINT);
    layer.bounds=self.bounds;
    layer.anchorPoint=CGPointZero;
    layer.position=CGPointMake(0, 0);
    layer.backgroundColor=self.backgroundColor.CGColor;
    layer.masksToBounds=NO;
    // 创建动画
    CABasicAnimation *anim = [CABasicAnimation animation];
    // 描述下修改哪个属性产生动画
    anim.keyPath = @"position";
    // 设置值
    anim.toValue = [NSValue valueWithCGPoint:CGPointMake(self.bounds.size.width , 0)];
    //动画时长
    anim.duration=_linetime;
    anim.delegate=self;
    // 设置动画完成的时候不要移除动画
    anim.removedOnCompletion = NO;
    // 设置动画执行完成要保持最新的效果
    anim.fillMode = kCAFillModeForwards;
    [layer addAnimation:anim forKey:nil];
    [self.layer addSublayer:layer];
}
-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    [_xylayer removeFromSuperlayer];
}
@end
