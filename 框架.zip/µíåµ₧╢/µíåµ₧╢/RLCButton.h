
#import <UIKit/UIKit.h>
@class RLCButton;
@protocol RLCButtonDelegate <NSObject>
@optional

-(void)didbutton:(RLCButton *)btn index:(int)index toindex:(int)toindex;
@end

@interface RLCButton : UIButton

@property(nonatomic,assign)id < RLCButtonDelegate >delegate;

-(instancetype)initWithFrame:(CGRect)frame colors:(NSArray <UIColor *>*)colors  sizes:(NSArray <NSNumber *> *)sizes;

@end
