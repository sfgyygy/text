//
//  UIScrollView+Helpr.h
//  框架
//
//  Created by Apple on 16/9/2.
//  Copyright © 2016年 框架. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Listeningkeyboard.h"

@class UIScrollView;

@protocol UIScrollViewDataSource <NSObject>

@optional

-(void)keyboardshangshen:(UIScrollView *)scrollView floath:(CGFloat)h;

-(void)keyboardxiajiang:(UIScrollView *)scrollView;

@end

@interface UIScrollView (Helpr)

-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor isKeyboard:(BOOL)isKeyboard;


/**
 *  监听键盘的类
 */
@property(nonatomic,retain)Listeningkeyboard * keyboard;

@property(nonatomic,assign)id <UIScrollViewDataSource >dataSource;

@end
