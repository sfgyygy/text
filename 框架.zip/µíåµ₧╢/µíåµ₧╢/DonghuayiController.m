//
//  DonghuayiController.m
//  框架
//
//  Created by Apple on 16/9/2.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "DonghuayiController.h"

@interface DonghuayiController ()

@property(nonatomic,retain)UIView * donghuaView;

@end

@implementation DonghuayiController

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self donghua];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.view.layer.transform = CATransform3DIdentity;
    _donghuaView.frame = CGRectMake(0, 0 , SCREEN_WIDTH , SCREEN_HEIGHT);
}
#pragma mark-----动画
-(void)donghua{
    [self.view addSubview:[[UIButton alloc]initWithFrame:CGRectMake(160, 100, 100, 30) text:@"点击动画" id:self sel:@selector(donghuaClick)]];
}
-(void)donghuaClick
{
    [self createdonghuaView];

    
}

-(void)createdonghuaView
{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH , SCREEN_HEIGHT) bgColor:[[UIColor clearColor] colorWithAlphaComponent:0]];
    [self.view.window addSubview:view];
    _donghuaView = view;
    UIView * view1 = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 300, SCREEN_WIDTH, 300) bgColor:[UIColor whiteColor]];
    [view addSubview:view1];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 300) text:@"" id:self sel:@selector(fanhuiClick)];
    [btn setBackgroundColor:[[UIColor clearColor] colorWithAlphaComponent:0]];
    [view addSubview:btn];
}
-(void)fanhuiClick
{
    CGFloat angle =  0.1 * M_PI;
    CATransform3D transfrom = CATransform3DMakeRotation(angle, 0.5, 0, 0);
    CGAffineTransform newTransform =  CGAffineTransformScale(self.view.window.transform, 1, 1);
    transfrom.m34 = 0.1 / 10.0;
    [UIView animateWithDuration:0.5 animations:^{
        self.view.layer.transform  = transfrom;
        [self.view setTransform:newTransform];
        _donghuaView.frame = CGRectMake( 0, SCREEN_HEIGHT , SCREEN_WIDTH , 300);
    } completion:^(BOOL finished) {
        [_donghuaView removeFromSuperview];
    }];
}
@end
