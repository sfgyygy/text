

/**
 *  这是自定义的些ui 的一些常用的数据设置  
 *  
 */



#import "Helpr.h"
#import "UILabel+MyHelpr.h"
#import "UIButton+Helpr.h"
#import "UIImage+Helpr.h"
#import "UIImageView+Helpr.h"
#import "UIImage+Helpr.h"
#import "UIView+Helpr.h"
#import "UITextField+Helpr.h"
#import "UIScrollView+Helpr.h"
#import "UITextView+Helpr.h"

#ifndef UiHelpr_h
#define UiHelpr_h


#define SIZI_HH(HH)  HH * SCREEN_WIDTH / 375.00

/**
 *  label的一些默认属性
 *
 */
#define UILABEL_TEXTCOLOR [UIColor blackColor]                     //标签的文字颜色
#define UILABEL_SIZE  SIZI_HH(17)                                  //标签的文字大小
#define UILABEL_INDEX 1                                            //标签的文字默认位子

#define UILABEL_TEXTCOLOR1 [UIColor blackColor] 
#define UILABEL_SIZE1  SIZI_HH(15)
/**
 *  按钮的一些默认属性
 *
 */
#define UIBUTTON_TEXTCOLOR [UIColor blackColor]                     //按钮文字的默认颜色
#define UIBUTTON_SIZE   SIZI_HH(17)                                 //按钮文字的默认大小
#define UIBUTTON_BIANKUANGCOLOR [UIColor blackColor]                //按钮边框的默认颜色
#define UIBUTTON_BIANKUANGSIZE 1                                    //按钮边框的默认宽度
#define UIBUTTON_BEIJINGCOLOR [UIColor clearColor]                  //按钮的背景颜色
#define UIBUTTON_CORNERRADIUS  5                                    //按钮的圆角
#define UIBUTTON_BACKIMAGENAME @""                                  //按钮的站位图片

#define YANZHENBTN_BIANKUANGCOLOR    RGB_R(100,100,100)     //验证码的边框颜色
#define YANZHENBTN_BEIJINGCOLOR      RGB_R(255,255,255)     //验证码的背景颜色
#define YANZHENBTN_TITSIZE           SIZI_HH(17)
#define YANZHENGBTN_TITTECOLOR       RGB_R(0,0,0)           //验证码的文字颜色

/**
 *  UIImageView的占位图片
 */
#define UIIMAGEVIEW_ZHANWEIIMAGE @""                                //图片view的占位图片

/**
 *  UIView+Helpr.H
 *
 *  @param 80
 *  @param 80
 *  @param 80
 *
 *  @return
 */
#define NAMELABEL_TEXTCOLOR  RGB_R(80,80,80);                   //nametextLabel的文字颜色
#define NAMELABEL_TEXTSIZI(HH)   SIZI_HH(HH)                    //nametextLabel的文字大小

/**
 *  image
 *
 *  @return
 */
#define IMAGE_XIAZAISHIBAI @""                                  //图片下载失败的图
#define IMAGEVIEW_ZUOJIANTOUNAME2 @"箭头2"                           //左箭头

#endif /* UiHelpr_h */
