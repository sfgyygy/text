

#ifndef MyColor_h
#define MyColor_h


//颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r green:g blue:b alpha:a]

#define RGB(r,g,b) RGBA(r,g,b,1.0f)

#define RGB_R(r,g,b) [UIColor colorWithRed:r/255.00 green:g/255.00 blue:b/255.00 alpha:1.0f]

#define VIEW_TEXTCOLOR  RGB_R(140, 140, 140)

#define VIEW_TEXTCOLOR1 RGB_R(0, 0, 0)

//项目的主要4个颜色
#define ZHUSE_COLOR1  RGB_R(255,0,0)   

#define ZHUSE_COLOR2  RGB_R(0,213,188)

#define ZHUSE_COLOR3  RGB_R(251,32,123)

#define ZHUSE_COLOR4  RGB_R(255,33,55)

#endif /* MyColor_h */
