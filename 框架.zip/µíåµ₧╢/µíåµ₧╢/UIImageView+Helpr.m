

#import "UIImageView+Helpr.h"

@implementation UIImageView (Helpr)

-(instancetype)initWithFrame:(CGRect)frame image:(nullable UIImage *)image
{
    if (self = [self initWithFrame:frame]) {
        if (image) {
            self.image = image;
        }else
        {
             self.image = [UIImage imageNamed:UIIMAGEVIEW_ZHANWEIIMAGE];
        }
    }
    return  self;
}

-(void)setimage:(nullable UIImage *)image withurl:(NSString *)url
{
    //添加 
  __block  UIActivityIndicatorView *activ=[UIImage downloadingImageActivityIndicatorView:CGRectMake(self.bounds.size.width/2-5,self.bounds.size.height/2-5 , 10, 10)];
    [self addSubview:activ];
    if (!self.image) {
        if (image) {
            self.image = image;
        }else {
            self.image = [UIImage imageNamed:UIIMAGEVIEW_ZHANWEIIMAGE];
        }
    }else {
        dispatch_queue_t queue=dispatch_queue_create("downimage", DISPATCH_QUEUE_CONCURRENT);
        dispatch_async(queue, ^{
            UIImage *image=[UIImage setimageWithURL:url];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (image) {
                    self.image=image;
                }else
                {
                    self.image = [UIImage imageNamed:IMAGE_XIAZAISHIBAI];
                }
                
                [activ removeFromSuperview];
            });
        });
    }
}
-(void)setimageWithurl:(NSString *)url{
    [self setimage:[UIImage imageNamed:UIIMAGEVIEW_ZHANWEIIMAGE] withurl:url];
}

@end
