//
//  Helpr.m
//  XM
//
//  Created by Macintosh HD on 16/4/16.
//  Copyright © 2016年 XM. All rights reserved.
//

const CGFloat Size_labeltext = 15 ;

#import "Helpr.h"

@implementation Helpr

+(NSString*)DataTOjsonString:(id)object
{
    NSString *jsonString = nil;
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:object
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

//手机号码验证
+ (BOOL) justMobile:(NSString *)mobile
{
    NSString *phoneRegex = @"^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}
+ (NSDictionary *)getTodayDate
{
    NSDate *today = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSCalendarUnit unit = kCFCalendarUnitYear|kCFCalendarUnitMonth|kCFCalendarUnitDay;
    NSDateComponents *components = [calendar components:unit fromDate:today];
    NSString *year = [NSString stringWithFormat:@"%ld", (long)[components year]];
    NSString *month = [NSString stringWithFormat:@"%02ld", (long)[components month]];
    NSString *day = [NSString stringWithFormat:@"%02ld", (long)[components day]];
    NSMutableDictionary *todayDic = [[NSMutableDictionary alloc] init];
    [todayDic setObject:year forKey:@"year"];
    [todayDic setObject:month forKey:@"month"];
    [todayDic setObject:day forKey:@"day"];
    return todayDic;
}
//用户名
+ (BOOL) justUserName:(NSString *)name
{
    NSString *userNameRegex = @"^[A-Za-z0-9]{6,20}+$";
    NSPredicate *userNamePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",userNameRegex];
    BOOL B = [userNamePredicate evaluateWithObject:name];
    return B;
}
//密码
+ (BOOL) justPassword:(NSString *)passWord
{
    NSString *passWordRegex = @"^[a-zA-Z0-9]{6,16}+$";
    NSPredicate *passWordPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",passWordRegex];
    return [passWordPredicate evaluateWithObject:passWord];
}
//判断是不是汉字
+(BOOL)isChinese:(NSString *)string{

    NSString *match = @"(^[\u4e00-\u9fa5]+$)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"%@ matches %@",string, match];
    return [predicate evaluateWithObject:self];
}

//字符串文字的长度
+(CGFloat)widthOfString:(NSString *)string font:(UIFont *)font height:(CGFloat)height
{
    NSDictionary * dict=[NSDictionary dictionaryWithObject: font forKey:NSFontAttributeName];
    CGRect rect=[string boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, height) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil];
    return rect.size.width;
}
//字符串的宽度
+(CGFloat)heightOfString:(NSString *)string font:(UIFont *)font width:(CGFloat)width
{
    CGRect bounds;
    NSDictionary * parameterDict=[NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
    bounds=[string boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:parameterDict context:nil];
    return bounds.size.height;
}


+(void)setalertmessage:(NSString *)message delegate:(nullable id)delegate{
    [self setalemessage:message delegate:delegate Title:@"系统提示"];
}
+(void)setalertErrormessage:(NSString *)message delegate:(nullable id)delegate{
    [self setalemessage:message delegate:delegate Title:@"Error"];
}
+(void)setalemessage:(NSString *)message delegate:(nullable id)delegate Title:(NSString *)Title{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:Title message:message delegate:delegate cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
}
+(void)setalertTishimessage:(NSString *)message delegate:(nullable id)delegate{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"版本更新" message:message delegate:delegate cancelButtonTitle:nil otherButtonTitles:@"现在就去",@"下次再说",nil];
    [alert show];
}
+(void)setalertTishimessage:(NSString *)message delegate:(nullable id)delegate array:(NSArray *)array{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:delegate cancelButtonTitle:nil otherButtonTitles:array[0],array[1],nil];
    [alert show];
}

+ (UIViewController *)getCurrentVC{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        
        for(UIWindow * tmpWin in windows)
        {
            if (tmpWin.windowLevel == UIWindowLevelNormal)
            {
                window = tmpWin;
                break;
            }
        }
    }
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else
        result = window.rootViewController;
    return result;
}
/*****
 当前控制器添加转场动画
 */
+(void)getCurrentVC:(int)index timer:(CGFloat)timer{
    NSArray *array=@[@"pageCurl",@"pageUnCurl",@"rippleEffect",@"suckEffect",@"cube",@"oglFlip",@"kCATransitionFade",@"kCATransitionMoveIn",@"kCATransitionPush",@"kCATransitionReveal"];
    if (index>=array.count&&index<0) {
        return ;
    }
    CATransition *animation2=[CATransition animation];
    animation2.type=array[index];
    animation2.duration=timer;
    animation2.subtype=kCATransitionFromRight;
    [self getCurrentVCanimation:animation2];
}
+(void)getCurrentVCanimation:(CAAnimation *)animation{
    [[self getCurrentVC].view.layer addAnimation:animation forKey:nil];
}

//文字输入框
+(UITextField *)TextFieldWithfram:(CGRect)fram pliceholder:(NSString *)pliceholder borderStyle:(UITextBorderStyle )borderStyle
{
    UITextField  *useryanzhengma=[[UITextField alloc]initWithFrame:fram];
    useryanzhengma.keyboardType=UIKeyboardTypeDefault;
    useryanzhengma.backgroundColor=[UIColor whiteColor];
    useryanzhengma.placeholder=pliceholder;
    useryanzhengma.borderStyle = borderStyle;
    useryanzhengma.clearButtonMode=UITextFieldViewModeWhileEditing;
    return useryanzhengma;
}
//密码输入框
+(UITextField *)TextFieldmimaWithfram:(CGRect)fram pliceholder:(NSString *)pliceholder borderStyle:(UITextBorderStyle )borderStyle
{
    UITextField  *useryanzhengma= [self TextFieldWithfram:fram pliceholder:pliceholder borderStyle:borderStyle];
    useryanzhengma.secureTextEntry=YES;
    return useryanzhengma;
}
+(NSMutableArray *)arrayWith:(NSArray *)fromArray toArray:(NSArray *)toArray
{
    NSMutableArray * retuArray = [NSMutableArray arrayWithCapacity:10];
    for (int i = 0; i < fromArray.count; i++) {
        //添加每一个元素
        [retuArray addObject:fromArray[i]];
        for (int j = 0 ; j<toArray.count; j++) {
            //判断小元素也没有这个对象
            if ([fromArray[i] isEqual:toArray[j]]) {
                //有就删除这个对象
                [retuArray removeObject:fromArray[i]];
            }
        }
    }
    return  retuArray;
}

+(NSArray *)arraywithstr:(NSString *)str
{
    NSString *plistPath=[[NSBundle mainBundle] pathForResource:str  ofType:@"plist"];
    return  [NSArray arrayWithContentsOfFile:plistPath];
}


@end
