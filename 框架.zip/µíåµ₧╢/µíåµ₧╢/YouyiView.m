//
//  YouyiView.m
//  框架
//
//  Created by Apple on 16/9/8.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "YouyiView.h"
#import <CoreMotion/CoreMotion.h>

@interface YouyiView () <UICollisionBehaviorDelegate,UIAccelerometerDelegate>
/**
 *  宽度
 */
@property(nonatomic,assign)CGFloat  view_w;
/**
 *  高度
 */
@property(nonatomic,assign)CGFloat  view_h;
/**
 *  所有动画效果添加
 */
@property(nonatomic,strong)UIDynamicAnimator *animator;
/**
 *  保存所有的球
 */
@property (nonatomic,strong)NSMutableArray *views;
/**
 *  正在弹射的球
 */
@property(nonatomic,strong)UILabel * label;
/**
 *  球的宽度
 */
@property(nonatomic,assign)CGFloat label_w;
/**
 *  计算最右边的球的位子
 */
@property(nonatomic,assign)int label_i;
/**
 *  重力行为
 */
@property(nonatomic,strong)UIGravityBehavior *grb;

@property(nonatomic,strong)CMMotionManager *motionManager;
/**
 *  当前的重力系数
 */
@property(nonatomic,assign)CGFloat zhongli;
/**
 *  所有的捕捉行为
 */
@property (nonatomic,strong)NSMutableArray<UISnapBehavior*> *snaps;

@property(nonatomic,retain)UICollisionBehavior * clb;
//碰撞行为
@property(nonatomic,retain)UIDynamicItemBehavior * itemBehavior;
//撞针
@property(nonatomic,copy)NSString * zhuangzhenStr;

@property (nonatomic, strong) UIBezierPath *path;
//撞针view
@property(nonatomic,strong)UIView * lineView;

@property(nonatomic,strong)NSMutableArray * labelArray;

@end


@implementation YouyiView

- (UIBezierPath *)path
{
    if (_path == nil) {
        _path = [UIBezierPath bezierPath];
    }
    return _path;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self.view_w = 320;
    self.view_h = 500;
    self.label_w = 15;
    self.views=[NSMutableArray array];   //初始化数组
    self.snaps=[NSMutableArray array];   //初始化数组
    self.labelArray  = [NSMutableArray array];
    if (self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, 320, 500)]) {
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor whiteColor];
        [self.layer setBorderWidth:1];
        [self.layer setBorderColor:[UIColor redColor].CGColor];
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    [self chuangjianqiu];
    [self huaxian];
}

-(void)chuangjianqiu
{
    for (int i = 0; i < 10; i++) {
        UILabel *view = [[UILabel alloc]initWithFrame:CGRectMake(30,self.view_h - 100, self.label_w, self.label_w)];
        view.backgroundColor = [UIColor colorWithRed:(arc4random()%255)/255.0 green:(arc4random()%255)/255.0 blue:(arc4random()%255)/255.0 alpha:1];
        view.text=[NSString stringWithFormat:@"%d",i];
        view.layer.cornerRadius = self.label_w / 2;
        view.textAlignment = NSTextAlignmentCenter;
        view.font = [UIFont systemFontOfSize:7];
        [view setClipsToBounds:YES];
        //1.创建捕捉行为
        UISnapBehavior *snap = [[UISnapBehavior alloc]initWithItem:view snapToPoint:CGPointMake(50, self.view_h - 100)];
        //设置防震系数（0~1，数值越大，震动的幅度越小）
        //   snap.damping=arc4random_uniform(10)/10.0;
        [self.snaps addObject:snap];   //把捕捉行为保存
        [self.views addObject:view];   //把数字view 保存数组
        [self addSubview:view];
    }
    self.animator = [[UIDynamicAnimator alloc]initWithReferenceView:self];
    //设置碰撞行为
    UICollisionBehavior *clb =[[UICollisionBehavior alloc]initWithItems:self.views];
    [clb setCollisionMode:0];
     clb.translatesReferenceBoundsIntoBoundary=YES;
    
    UIDynamicItemBehavior * itemBehavior = [[UIDynamicItemBehavior alloc] initWithItems:self.views];
    self.itemBehavior = itemBehavior;
    itemBehavior.elasticity = 0.001;    //设置碰撞弹力系数
    [_animator addBehavior:itemBehavior];  //将itemBehavior添加到动力动画中
    
    //设置代理
    clb.collisionDelegate = self;
    self.clb = clb ;

    //添加碰撞行为
    [self.animator addBehavior:clb];
    
    //创建重力行为
    UIGravityBehavior *grb = [[UIGravityBehavior alloc]initWithItems:self.views];
    grb.magnitude = 0.2;
    //添加重力行为
    [self.animator addBehavior:grb];
    
    
    self.grb=grb;
    
    self.motionManager = [[CMMotionManager alloc] init];
    //设置时间 单位为妙
    self.motionManager.accelerometerUpdateInterval = 1;
    [self.motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue currentQueue] withHandler:^(CMAccelerometerData * _Nullable accelerometerData, NSError * _Nullable error) {
        //        double size =1-fabs(accelerometerData.acceleration.z);
        //        self.grb.magnitude=9.8 * size;
        //计算角度
        double angle = atan2(-1*accelerometerData.acceleration.y, accelerometerData.acceleration.x);
        //        NSLog(@"%f",angle);
                self.grb.angle = angle;
        if (angle >1) {
            self.grb.angle =angle;
            self.zhongli = angle;
        }
       // self.grb.angle = 45;
        for (int i = 0; i < self.views.count; i++) {
            UILabel * label = (UILabel *)self.views[i];
            if (label.frame.origin.x < 0 || label.frame.origin.y <0 ||label.frame.origin.x > self.view_w || label.frame.origin.y > self.view_h) {
                //出现异常
              //  [self.views removeObject:label];
                NSLog(@"异常");
            }else {
              //  NSLog(@"%@--------%@",label.text,NSStringFromCGPoint(label.layer.position));
                CGFloat labelx = label.layer.position.x;
                CGFloat labely = label.layer.position.y;
                //判断位子
                for (int j = 0 ; j < self.labelArray.count; j++) {
                    CGRect frame = CGRectFromString(self.labelArray[j]);
                    CGFloat x = frame.origin.x;
                    CGFloat y = frame.origin.y;
                    
                    if (labelx < x + self.label_w *0.5 && labelx > x - self.label_w * 0.5 && labely < y + 37 && labely > y +22) {
                        [self qiujindongwith:label tag:j];
                         self.labelArray[j] = NSStringFromCGRect(CGRectMake(0, 0, 0, 0));
                    }
                }
            }
        }
    }];

}
-(void)huaxian
{
    CGFloat chushi_h = 70;
    //划直线的数据
    NSMutableArray <NSString * > *frameArray = [NSMutableArray arrayWithCapacity:10];
    //右边线
    [frameArray addObject:NSStringFromCGRect(CGRectMake(self.view_w - self.label_w * 1.5, chushi_h +20, 1, self.view_h - chushi_h - self.label_w - 30))];
    //装帧
    _zhuangzhenStr = NSStringFromCGRect(CGRectMake(self.view_w - self.label_w * 1.5 - 3, self.view_h - self.label_w * 1.5, 3, self.label_w * 1.5 - 4));
    [frameArray addObject:_zhuangzhenStr];
    //右边边线
    [frameArray addObject:NSStringFromCGRect(CGRectMake(self.view_w - 1, 0, 1, self.view_h))];
    //底边边线
    [frameArray addObject:NSStringFromCGRect(CGRectMake(self.view_w - self.label_w * 1.5, self.view_h , self.label_w * 1.5 , 0.5))];
    //划线
    for (int i = 0; i < frameArray.count; i++) {
        CGRect frame = CGRectFromString(frameArray[i]);
        UIBezierPath *path =[UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:0.5];
        [self.clb addBoundaryWithIdentifier:frameArray[i] forPath:path];
        [self Drawxianframe:frame bgcolor:[UIColor redColor] tag:100 +i];
    }
    
    NSMutableArray  <NSString *> * point1Array = [NSMutableArray arrayWithCapacity:10];
    NSMutableArray  <NSString *> * point2Array = [NSMutableArray arrayWithCapacity:10];
    //下面的斜线 坡度
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(0, self.view_h - self.label_w * 3))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w - self.label_w, self.view_h))];
    //左边的边线
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(1, 150))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(2, self.view_h))];
    //左边的边斜线
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(0, 150))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w / 2 - 50, self.view_h - self.label_w * 5))];
    //右边 上面斜线
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w / 2 + 50, self.view_h - self.label_w * 7))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w - self.label_w * 1.5, 150))];
    //右边中间
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w / 2 + 50, self.view_h - self.label_w * 7))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w / 2 + 50, self.view_h - self.label_w * 2.5))];
    //右边下面
    [point1Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w / 2 + 50, self.view_h - self.label_w * 2.5))];
    [point2Array  addObject:NSStringFromCGPoint(CGPointMake(self.view_w - self.label_w * 1.5, self.view_h - self.label_w * 2))];

    for (int i = 0 ; i < point1Array.count; i++) {
        CGPoint point1 = CGPointFromString(point1Array[i]);
        CGPoint point2 = CGPointFromString(point2Array[i]);
        [self.clb addBoundaryWithIdentifier:[NSString stringWithFormat:@"%@ %@",point1Array[i],point2Array[2]] fromPoint:point1 toPoint:point2];
        [self strokepathtopoint:point1 addpoint:point2];
    }
    
    //画顶部的弧形
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path addArcWithCenter:CGPointMake(self.view_w / 2, self.view_h) radius:self.view_h   startAngle:225 endAngle:0 clockwise:NO];
    [self.clb addBoundaryWithIdentifier:@"line1" forPath:path];
    
//    CGContextRef context = UIGraphicsGetCurrentContext(); CGContextSetRGBStrokeColor(context, 0, 0, 1, 1);//改变画笔颜色
//    CGContextSetLineWidth(context, 1);
//    CGContextAddArc(context, self.view_w /2, self.view_h, self.view_h, 180, 0, 0);
//    CGContextClosePath(context);
//    CGContextDrawPath(context, kCGPathFill);
    
    int  jj = 101;
    //画框
    for (int i = 0 ; i < 5 ; i++) {
        for (int j = i; j < 6; j++) {
            CGRect Frame ;
            if (i == 0) {
                Frame = CGRectMake(25 + 50 * j - 0.5, 60 * i + chushi_h  , 1, 1);
            }else if(i == 1){
                Frame = CGRectMake(50 * j - 0.5, 60 * i + chushi_h , 1, 1);
            }else if(i == 2){
                Frame = CGRectMake(50 * j - 0.5 -25, 60 * i + chushi_h , 1, 1);
            }else if (i == 3){
                Frame = CGRectMake(50 * j - 0.5 - 50, 60 * i + chushi_h , 1, 1);
            }else if(i ==4){
                Frame = CGRectMake(50 * j - 0.5 - 75, 60 * i + chushi_h , 1, 1);
            }
            [self DrawkuangWithFrame:Frame tag:jj];
            jj++;
        }
    }
}
#pragma mark-----画框
-(void)DrawkuangWithFrame:(CGRect)Frame tag:(int)tag
{
    [self.labelArray addObject:NSStringFromCGRect(Frame)];
    UIView * zhenview = [[UIView alloc]initWithFrame:Frame];
    zhenview.backgroundColor = [UIColor redColor];
    zhenview.layer.cornerRadius = 0.5;
    [self addSubview:zhenview];
    //划点
    UIBezierPath *path =[UIBezierPath bezierPathWithRoundedRect:Frame cornerRadius:0.5];
    [self.clb addBoundaryWithIdentifier:NSStringFromCGRect(Frame) forPath:path];
    //划右边的框
    CGPoint point1 = CGPointMake(Frame.origin.x - (self.label_w / 2.0 + 4.5), Frame.origin.y +27);
    CGPoint point2 = CGPointMake(Frame.origin.x - (self.label_w / 2.0 + 2.5), Frame.origin.y +37);
    [self.clb addBoundaryWithIdentifier:[NSString stringWithFormat:@"zuokuang_%d",tag] fromPoint:point1 toPoint:point2];
    [self strokepathtopoint:point1 addpoint:point2];
    //划左边的框
    CGPoint point3 = CGPointMake(Frame.origin.x + (self.label_w / 2.0 + 4.5), Frame.origin.y +27);
    CGPoint point4 = CGPointMake(Frame.origin.x + (self.label_w / 2.0 + 2.5), Frame.origin.y +37);
    [self.clb addBoundaryWithIdentifier:[NSString stringWithFormat:@"youkuang_%d",tag] fromPoint:point3 toPoint:point4];
    [self strokepathtopoint:point3 addpoint:point4];
    //划下面的框
    CGPoint point5 = CGPointMake(Frame.origin.x - (self.label_w / 2.0 + 2.5), Frame.origin.y +37);
    CGPoint point6 = CGPointMake(Frame.origin.x + (self.label_w / 2.0 + 2.5), Frame.origin.y +37);
    [self.clb addBoundaryWithIdentifier:[NSString stringWithFormat:@"xiakuang_%d",tag] fromPoint:point5 toPoint:point6];
    [self strokepathtopoint:point5 addpoint:point6];
}
-(void)Drawxianframe:(CGRect)frame bgcolor:(UIColor *)color tag:(int)tag
{
    UIView *lineView1 = [[UIView alloc] initWithFrame:frame];
    lineView1.backgroundColor = color;
    lineView1.tag = tag;
    if (tag == 101) {
        self.lineView = lineView1;
    }
    [self addSubview:lineView1];
}

-(void)drawkuangFrame:(CGRect)frame bgcolor:(UIColor *)color index:(int)index
{
    
}
#pragma mark----划斜线
-(void)strokepathtopoint:(CGPoint)point1 addpoint:(CGPoint)point2
{
    [self.path moveToPoint:point1];
    [self.path addLineToPoint:point2];
    [self.path stroke];
}

-(void)kaishiBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    CGPoint p ;
    NSArray * array = [touches allObjects];
    for (int i = 0 ; i< array.count; i++) {
        UITouch * tou = [touches allObjects][i];
        p = [tou locationInView:self.window];
        
    }
    self.label_i = -1;
    for (int i = 0; i < self.views.count; i++) {
        UILabel * label = self.views[i];
        if (label.frame.origin.x >= self.view_w - self.label_w * 1.5 && label.frame.origin.y > self.view_h - self.label_w * 5) {
            self.label_i = i;
        }
    }
    if (self.label_i == -1) {
        return ;
    }
    for (int i =0; i<self.snaps.count; i++) {
        if ([self.animator.behaviors containsObject:self.snaps[i]]) {
            [self.animator removeBehavior:self.snaps[i]];
        }
        if (self.label_i == i) {
            CGPoint  point = CGPointMake(self.view_w - arc4random()%(30) -10, arc4random()%(100)+50);
            point = CGPointMake(self.view_w - 35, self.view_h / 3 * 2 - p.y / self.view_h * 100);
            UILabel * label1 = (UILabel *)self.views[i];
            if (label1.frame.origin.x < self.view_w - 40) {
                return ;
            }
            
            UIPushBehavior *push = [[UIPushBehavior alloc]initWithItems:@[self.views[i]] mode:UIPushBehaviorModeInstantaneous];
            //    设置推的方向
            //    x正右负左  y正下 负上
            push.pushDirection = CGVectorMake(0, -1);
            push.magnitude = p.x / SCREEN_WIDTH  + arc4random()%(100) * 0.00001  ;
            //添加到效果器里面
            [self.animator addBehavior:push];
        }
    }
}

-(BOOL)zhunbeijiuxu
{
    for (int i = 0; i < self.views.count; i++) {
        UILabel * label = self.views[i];
        if (label.frame.origin.x >= self.view_w - self.label_w * 1.5) {
            return  YES;
        }
    }
    return NO;
}
-(void)zhunbei
{
    [self.clb removeBoundaryWithIdentifier:_zhuangzhenStr];
    self.lineView.alpha = 0;
}
-(UIDynamicItemCollisionBoundsType)collisionBoundsType{
    return UIDynamicItemCollisionBoundsTypeEllipse;
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.snaps enumerateObjectsUsingBlock:^(UISnapBehavior * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [self.animator removeBehavior:obj];
    }];
}
- (void)collisionBehavior:(UICollisionBehavior*)behavior beganContactForItem:(id <UIDynamicItem>)item withBoundaryIdentifier:(nullable id <NSCopying>)identifier atPoint:(CGPoint)p{
    if (p.y > self.view_h - self.label_w && p.x > self.view_w - self.label_w * 1.5) {
        if ([self.clb boundaryWithIdentifier:_zhuangzhenStr]) {
            return ;
        }
        CGRect frame = CGRectFromString(_zhuangzhenStr);
        UIBezierPath *path =[UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:0.5];
        [self.clb addBoundaryWithIdentifier:_zhuangzhenStr forPath:path];
        self.lineView.alpha = 1;
    }
}

#pragma mark-----球进洞
-(void)qiujindongwith:(UILabel *)label tag:(int)tag
{
    if ([self.delegate respondsToSelector:@selector(jihaoweijinqiu:)]) {
        [self.delegate jihaoweijinqiu:tag];
    }
    CGRect frmae = CGRectFromString(self.labelArray[tag]);
    
    UILabel * label1 = [[UILabel alloc]initWithFrame:CGRectMake(frmae.origin.x - self.label_w * 0.5, frmae.origin.y + 22, self.label_w, self.label_w) text:label.text];
    label1.textAlignment =  NSTextAlignmentCenter;
    label1.backgroundColor = [UIColor redColor];
    label1.layer.cornerRadius = self.label_w * 0.5;
    [label1 setClipsToBounds:YES];
    label1.backgroundColor = label.backgroundColor;
    [self addSubview:label1];
    
    [self.clb removeItem:label];
    [self.views removeObject:label];
    [label removeFromSuperview];
    //删除框框  xiakuang_   zuokuang_  youkuang_
    [self.clb removeBoundaryWithIdentifier:[NSString stringWithFormat:@"youkuang_%d",tag + 101]];
    [self.clb removeBoundaryWithIdentifier:[NSString stringWithFormat:@"zuokuang_%d",tag + 101]];
    [self.clb removeBoundaryWithIdentifier:[NSString stringWithFormat:@"xiakuang_%d",tag + 101]];
}
@end
