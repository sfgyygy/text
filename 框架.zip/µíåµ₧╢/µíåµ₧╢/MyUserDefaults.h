



#define ISFIRST          @"ISFIRST"                        //判段是不是第一次使用app
#define USER_NAME        @"USER_NAME"                      //用户用户名
#define USER_PASSWORD    @"USER_PASSWORD"                  //用户密码
#define USER_ID          @"USER_ID"                        //用户id

#import <Foundation/Foundation.h>
@interface MyUserDefaults : NSObject

NS_ASSUME_NONNULL_BEGIN

XMGSingletoH
/**
 *  插入一个对象到 NSUserDefaults
 *
 *  @param value       值
 *  @param defaultName 键
 */
-(void)setObject:(nullable id)value forKey:(NSString *)defaultName;
/**
 *  取 NSUserDefaults 对应的 defaultName 值
 *
 *  @param defaultName 建名称
 */
-(nullable id)objectForKey:(NSString *)defaultName;
/**
 *  删除保存的值
 *
 *  @param defaultName nil
 */
-(void)removeKey:(NSString *)defaultName;

NS_ASSUME_NONNULL_END
@end
