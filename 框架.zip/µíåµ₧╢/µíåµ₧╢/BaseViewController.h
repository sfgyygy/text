

//－－－－－－－－－－－－－－－－－所有的类的跟类 －－－－－－－－－－－－－－－－－－－－－
//－－－－－－－－－－－－－－－－包含导航栏 个人信息 下载数据  保存缓存 －－－－－－－－－－

#import <UIKit/UIKit.h>
#import "MyHelpr.h" 
#import "GerenModel.h"
#import "NavView.h"
#import "MytableView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UIViewController <NavViewDelegate>

@property (nonatomic, retain, readonly) NSDictionary *dict;
/**
 *  单例  个人信息 类
 */
@property(nonatomic,retain)GerenModel * model ;
/**
 *  自定义导航栏
 */
@property(nonatomic,retain)NavView * navView;
/**
 *  跟控制器创建的方法
 *
 *  @param dict json
 *
 *  @return self
 */
- (instancetype)initWithDict:(NSDictionary *)dict ;
/**
 *  带返回的创建
 *
 *  @param str 自定义导航栏的文字
 *
 *  @return self
 */
-(instancetype)initWithNavTitle:(nullable NSString *)str;

@property(nonatomic,copy)NSString * titlestr;
/**
 * get 下载数据  不保存缓存
 *
 *  @param str   下载地址
 *  @param index  index < 0  下载的地址不拼接  index > 0 拼接地址   index>100  数据解析出来是数组  <100是josn >50 打印数据
 */
-(void)getdownDatas:(NSString *)str index:(int)index ;
-(void)getdownDatas:(NSString *)str index:(int)index iscache:(BOOL)iscache ;
/**
 *  post 下载数据  不保存缓存
 *
 *  @param str   str   下载地址
 *  @param dict  上传的josn
 *  @param index index  index < 0  下载的地址不拼接  index > 0 拼接地址   index>100  数据解析出来是数组  <100是josn >50 打印数据
 */
-(void)postdownDatas:(NSString *)str dict:(nullable NSDictionary *)dict index:(int)index ;
-(void)postdownDatas:(NSString *)str dict:(nullable NSDictionary *)dict index:(int)index iscache:(BOOL)iscache;
/**
 *  解析数据  子类要重写
 *  正常的数据解析
 *  @param responseDict 下载的数据
 *  @param index        标示 index < 0  下载的地址不拼接  index > 0 拼接地址   index>100  数据解析出来是数组  <100是josn >50 打印数据
 */
-(void)duxu:(NSDictionary *)responseDict index:(int)index;
/**
 *  解析数据  子类要重写
 *  非正常的数据解析
 *  @param responseDict 下载的数据
 *  @param index        标示
 */
-(void)duxu1:(NSDictionary *)responseDict index:(int)index;
/**
 *  解析数据 子类要重写
 *  index>100  解析出来的是数组
 *  @param dataArray 下载的数据
 *  @param index     标示
 */
-(void)duxuArray:(NSArray *)dataArray index:(int)index;
/**
 *  错误数据的解析
 *
 *  @param error 错误信息
 *  @param index 标示
 */
-(void)duxucuowu:(NSError *)error index:(int)index;
/**
 *  下载数据 刷新小圈
 */
-(void)createShuaxin;
/**
 *  刷新小圈
 */
@property(nonatomic,retain)UIActivityIndicatorView  * actView;
/**
 *  推出新视图
 *
 *  @param str   控制器的名称
 *  @param title 导航栏的名称
 */
-(void)popControllerwithstr:(NSString *)str title:(NSString *)title;

@end

@interface BaseMytabViewController : BaseViewController <MyTableViewDelegate,MyTableViewCellDelegate>

@property(nonatomic,retain)MyTableView * myTableView;

-(void)createTableView;

@end

NS_ASSUME_NONNULL_END
