//
//  BanbenGengxin.m
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "BanbenGengxin.h"

@implementation BanbenGengxin
XMGSingletoM
#pragma mark---版本更新
-(void)test{
    if (kAppID.length == 0) {
        NSLog(@"kAppID没有填写");
        return ;
    }
    NSString *storeString = [NSString stringWithFormat:@"http://itunes.apple.com/lookup?id=%@", kAppID];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:storeString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *appData = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        NSArray *versionsInAppStore = [[appData valueForKey:@"results"] valueForKey:@"version"];
        if ( ![versionsInAppStore count] ) {
            return;
        }
        else {
            NSString *currentAppStoreVersion = [versionsInAppStore objectAtIndex:0];
            NSString *currentVersion = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
            if ([currentVersion compare:currentAppStoreVersion options:NSNumericSearch] == NSOrderedAscending) {
                [Helpr setalertTishimessage:[NSString stringWithFormat:@"发现新版本(%@),是否更新", currentAppStoreVersion] delegate:self];
            }
            else {
                return;
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        NSString *iTunesString = [NSString stringWithFormat:@"https://itunes.apple.com/app/id%@", kAppID];
        NSURL *iTunesURL = [NSURL URLWithString:iTunesString];
        [[UIApplication sharedApplication] openURL:iTunesURL];
    }
}
#pragma mark---动画的代理
-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    [[Helpr getCurrentVC].view.layer removeAllAnimations];
}
@end
