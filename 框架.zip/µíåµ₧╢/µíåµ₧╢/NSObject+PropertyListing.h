//
//  NSObject+PropertyListing.h
//  个人
//
//  Created by Macintosh HD on 16/6/7.
//  Copyright © 2016年 个人学习. All rights reserved.
//
#import <objc/runtime.h>
#import <Foundation/Foundation.h>

@interface NSObject (PropertyListing)
/**
 *  获取所有属性
 *
 *  @return 数组
 */
- (NSArray *)getAllProperties;

@end
