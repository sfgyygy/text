//
//  ZhuanyeController.m
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "ZhuanyeController.h"

@interface ZhuanyeController ()

@property(nonatomic,retain)UITextField * tx;

@property(nonatomic,retain)UILabel * label;
@end

@implementation ZhuanyeController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [_label startAnimationIfNeeded];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self gundong];
    _tx = [[UITextField alloc]initWithfram:CGRectMake(10, 150, 100, 30) placeholder:@"测试件键盘" borderStyle:0];
    [self.view addSubview:_tx];

}
#pragma mark-----
-(void)quxiaojianpan
{
    [_tx resignFirstResponder];
}
#pragma mark-----uilabelw文字滚动
-(void)gundong
{
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(10, 100, 100, 30) text:@"asdfasdfsadfsadfasdfdsafsdafa"isdonghua:YES];
    //[label startAnimationIfNeeded];
    [self.view addSubview:label];
    _label = label;
}


@end
