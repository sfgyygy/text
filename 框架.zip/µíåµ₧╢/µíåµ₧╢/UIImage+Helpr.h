//
//  UIImage+Helpr.h
//  个人
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 个人学习. All rights reserved.
//

@interface UIImage (Helpr)

NS_ASSUME_NONNULL_BEGIN
/**
 *  根据url 下载图片 获取本地缓存  沙盒也没有图片
 *
 *  @param url 图片url
 *
 *  @return 返回图片
 */
+(nullable UIImage *)setimageWithURL:(NSString *)url;
/**
 *  根据指定连接地址  删除图片
 *
 *  @param url 图片的地址
 */
+(void)removeimageWithURL:(NSString *)url;
/**
 *  删除所有下载的图片
 */
+(void)removeAllimage;
/**
 *  系统图片缓冲图片  以url连接地址保持
 *
 *  @return 返回一个字典对象
 */
+(NSMutableDictionary  *)images;
/**
 *  判断一个data是不是图片类型
 *
 *  @param data
 *
 *  @return 是图片 返回图片类型  不是返回nil
 */
+ (NSString *)sd_contentTypeForImageData:(NSData *)data;
/**
 *  正在下载图片的动作
 *
 */
+(UIActivityIndicatorView *)downloadingImageActivityIndicatorView:(CGRect)fram;


NS_ASSUME_NONNULL_END
@end
