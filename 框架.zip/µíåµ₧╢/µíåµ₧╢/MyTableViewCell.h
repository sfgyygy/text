//
//  MyTableViewCell.h
//  个人
//
//  Created by Macintosh HD on 16/6/2.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTableViewModel.h"

@class MyTableViewCell;

@protocol MyTableViewCellDelegate <NSObject>

@optional

-(void)didsel:(MyTableViewCell *)Mycell btn:(UIButton *)btn model:(MyTableViewModel *)MyModel;

@end

@interface MyTableViewCell : UITableViewCell

@property(nonatomic,retain)MyTableViewModel *model;

@property(nonatomic,assign)id<MyTableViewCellDelegate> delegate;

-(void)createCell;
//设置cell的高度 以及背景颜色
-(void)createcell_h:(CGFloat)cellh bgcolor:(UIColor *)bgcolor xian_h:(CGFloat)xian_h;

@property(nonatomic,retain)UIView *xianView;

@end
