//
//
//
//-----------------------重新设置点击进入应用的位子-------------------------
//
//
//
//
#import <UIKit/UIKit.h>

@protocol NewFeatureViewControllerDeletage <NSObject>
/**
 *  点击直接进入应用  代理必须要实现
 */
-(void)didtext;

@end

@interface NewFeatureViewController : UIViewController

@property(nonatomic,assign)id<NewFeatureViewControllerDeletage>delegate;

@end
