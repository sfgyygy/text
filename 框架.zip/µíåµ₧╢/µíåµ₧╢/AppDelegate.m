//
//  AppDelegate.m
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()<NewFeatureViewControllerDeletage>

@property(nonatomic,retain)MyUserDefaults * userDefaults;

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    _userDefaults = [MyUserDefaults sharedInstance];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    if (![_userDefaults objectForKey:ISFIRST]) {
        //添加用户登录信息
        [_userDefaults setObject:[NSNumber numberWithBool:YES] forKey:ISFIRST];
        //欢迎页面
        NewFeatureViewController *vc=[[NewFeatureViewController alloc] init];
        vc.delegate=self;
        self.window.rootViewController = vc;
    } else {
        // 直接进入应用程序
        [self didtext];
        //开启线程 做些见不得人的东西
        [NSThread detachNewThreadSelector:@selector(test) toTarget:self withObject:nil];
    }
    [self.window makeKeyAndVisible];
    return YES;
}
//点击进入登录页面应用
-(void)didtext{
    if (![_userDefaults objectForKey:USER_ID]) {
        //用户已经登录获取 USER_ID
        MainTabBarViewController *tab=[[MainTabBarViewController alloc]initWithStringPlist:@"XMplist"];
        self.window.rootViewController=tab;
 
    }else {
        //用户没有登录

    }
}
- (void)applicationWillResignActive:(UIApplication *)application {
    //应用程序将要由活动状态切换到非活动状态时执行的委托调用，如按下home 按钮，返回主屏幕，或全屏之间切换应用程序等。
    
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    //在应用程序已进入后台程序时，要执行的委托调用。所以要设置后台继续运行，则在这个函数里面设置即可。
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    //在应用程序将要进入前台时(被激活)，要执行的委托调用，与applicationWillResignActive 方法相对应
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    //在应用程序已被激活后，要执行的委托调用，刚好与  applicationDidEnterBackground 方法相对应。
}

- (void)applicationWillTerminate:(UIApplication *)application {
    //在应用程序要完全退出的时候，要执行的委托调用
}
#pragma mark-----开启线程做些东西
-(void)test
{
    //判断版本更新
    [[BanbenGengxin sharedInstance]test];
    //检测网络
    [[MyCache sharedInstance] Detectnetwork];
}

@end
