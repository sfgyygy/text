//
//  UITextView+Helpr.m
//  框架
//
//  Created by Apple on 16/9/2.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "UITextView+Helpr.h"

@implementation UITextView (Helpr)

@dynamic placeholder;
__strong    NSString * _placeholder;
__strong    UILabel * _placeholderLabel;

-(void)setPlaceholder:(NSString *)placeholder
{
    _placeholder = placeholder;
    if (_placeholderLabel == nil) {
        _placeholderLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 3, self.bounds.size.width - 10, 25)];
        _placeholderLabel.font = [UIFont systemFontOfSize:15];
        _placeholderLabel.textColor = RGB_R(80, 80, 80);
        [self addSubview:_placeholderLabel];
        if(self.text.length > 0){
            _placeholderLabel.alpha = 0;
        }
    }
    _placeholderLabel.text = placeholder;
}

-(instancetype)initWithfram:(CGRect)fram placeholder:(NSString *)placeholder
{
    if (self = [self initWithFrame:fram]) {
        self.placeholder  = placeholder;
    }
    return  self;
}

-(BOOL)isSelectable
{
    if (self.text.length > 0) {
        _placeholderLabel.alpha = 0;
    }else {
        _placeholderLabel.alpha = 1;
    }
    return NO;
}

@end
