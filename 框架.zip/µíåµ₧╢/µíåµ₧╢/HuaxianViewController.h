//
//  HuaxianViewController.h
//  个人
//
//  Created by Macintosh HD on 16/7/6.
//  Copyright © 2016年 个人学习. All rights reserved.
//

#import "BaseViewController.h"
#import "HuaxianView.h"

@interface HuaxianViewController : BaseViewController

@property(nonatomic,strong)HuaxianView *huaxianView;

@end
