//
//  Helpr.h
//  XM
//
//  Created by Macintosh HD on 16/4/16.
//  Copyright © 2016年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Helpr : NSObject

NS_ASSUME_NONNULL_BEGIN
/**
 *  字典转字符串
 *
 *  @param object 字点
 *
 *  @return 字符串
 */
+(NSString*)DataTOjsonString:(id)object;
/**
 *  判断字符串手机号码
 *
 *  @param mobile 字符串
 *
 *  @return yes 可以 no  不可以
 */
+ (BOOL) justMobile:(NSString *)mobile;
/**
 *  返回当前日期
 *
 *  @return
 */
+ (NSDictionary *)getTodayDate;
/**
 *  判断字符串 是否可以为用户名
 *
 *  @param name 字符串
 *
 *  @return yes  可以为用户名  no 不能为密码
 */
+ (BOOL) justUserName:(NSString *)name;
/**
 *  判断字符串 是否可以为密码
 *
 *  @param passWord 字符串
 *
 *  @return yes  可以为密码  no 不能为密码
 */
+ (BOOL) justPassword:(NSString *)passWord;
/**
 *  判断一个字符串是否包含汉字
 *
 *  @param string 字符串
 *
 *  @return  yes 不包含  no 包含
 */
+(BOOL)isChinese:(NSString * )string;
/**
 *  计算字符串的宽度
 *
 *  @param string 字符串
 *  @param font   字体大小
 *  @param height 高度
 *
 *  @return 宽度
 */
+(CGFloat)widthOfString:(NSString * )string font:(UIFont* )font height:( CGFloat )height;
/**
 *  计算字符串的高度
 *
 *  @param string 字符串
 *  @param font   字体大小
 *  @param width  宽度长度
 *
 *  @return 高度
 */
+(CGFloat)heightOfString:(NSString * )string font:(UIFont* )font width:( CGFloat)width;

/**
 *  系统的提示框
 *
 *  @param message  提示信息
 *  @param delegate 代理
 */
+(void)setalertmessage:(NSString *)message delegate:(nullable id)delegate;
/**
 *  错误信息提示框
 *
 *  @param message  提示信息
 *  @param delegate 代理
 */
+(void)setalertErrormessage:(NSString *)message delegate:(nullable id)delegate;
/**
 *  提示框
 *
 *  @param message  提示信息
 *  @param delegate 代理
 *  @param Title    提示标题
 */
+(void)setalemessage:(NSString *)message delegate:(nullable id)delegate Title:(NSString *)Title;
/**
 *  版本选择框
 *
 *  @param message  提示信息
 *  @param delegate 代理
 */
+(void)setalertTishimessage:(NSString *)message delegate:(nullable id)delegate;
/**
 *  提示框
 *
 *  @param message  提示信息
 *  @param delegate 代理
 *  @param array    下面可点击按钮
 */
+(void)setalertTishimessage:(NSString *)message delegate:(nullable id)delegate array:(NSArray *)array;
/**
 *  取出当前视图控制器
 *
 *  @return 当前控制器
 */
+ ( UIViewController * )getCurrentVC;
/*****
 * 当前控制器添加转场动画  index:0-9 timer:时长  调用这个方法添加动画效果
 * 0 向上翻一页
 * 1 向下翻一页
 * 2 滴水效果
 * 3 收缩效果
 * 4 立方体
 * 5 上下翻转
 * 6 交叉淡化
 * 7 新视图移到旧视图
 * 8 新视图把旧视图推
 * 9 将旧视图移开,显示下面的新视图
 */
+(void)getCurrentVC:(int)index  timer:(CGFloat)timer;
/**
 *  添加自定义动画效果
 *
 *  @param animation 动画
 */
+(void)getCurrentVCanimation:(CAAnimation *)animation;

+(UITextField *)TextFieldWithfram:(CGRect)fram pliceholder:(NSString *)pliceholder borderStyle:(UITextBorderStyle )borderStyle
;
//密码输入框
+(UITextField *)TextFieldmimaWithfram:(CGRect)fram pliceholder:(NSString *)pliceholder borderStyle:(UITextBorderStyle )borderStyle
;
/**
 *  判断一个数组 在还一个数组不存在的对象
 *
 *  @param fromArray 大数组
 *  @param toArray   小数组
 *
 *  @return 数组
 */
+(NSMutableArray *)arrayWith:(NSArray *)fromArray toArray:(NSArray *)toArray;

/**
 *  查找plist
 *
 *  @param str 文件名称
 *
 *  @return 类型
 */
+(NSArray *)arraywithstr:(NSString *)str;

NS_ASSUME_NONNULL_END
@end
