//
//  GerenModel.m
//  框架
//
//  Created by Apple on 16/8/15.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "GerenModel.h"

@implementation GerenModel
XMGSingletoM
//保存用户信息
-(void)saveGerenModel{
    if (![self.userid isEqualToString:[[MyUserDefaults sharedInstance]objectForKey:USER_ID]]) {
        //删除用户绑定的一些信息   目前用一样的 不问
    }
    [[MyUserDefaults sharedInstance]setObject:self.userid forKey:USER_ID];
    [[MyUserDefaults sharedInstance]setObject:self.username forKey:USER_NAME];
    [[MyUserDefaults sharedInstance]setObject:self.userpassword forKey:USER_PASSWORD];
}
//读取用户信息
-(void)readGerenModel{
    self.userid = [[MyUserDefaults sharedInstance]objectForKey:USER_ID];
    self.userpassword = [[MyUserDefaults sharedInstance]objectForKey:USER_PASSWORD];
    self.username = [[MyUserDefaults sharedInstance]objectForKey:USER_NAME];
}
//删除保存的用户信息
-(void)removeGereModel
{
    [[MyUserDefaults sharedInstance]removeKey:USER_ID];
    [[MyUserDefaults sharedInstance]removeKey:USER_PASSWORD];
    [[MyUserDefaults sharedInstance]removeKey:USER_NAME];
    self.userid = nil;
    self.userpassword = nil;
    self.username = nil;
}
-(void)validationuserid
{
    
}
@end
