//
//  Listeningkeyboard.m
//  框架
//
//  Created by Apple on 16/9/1.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "Listeningkeyboard.h"

@implementation Listeningkeyboard

-(void)startlistening
{
    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    //增加监听，当键退出时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

-(void)stoplistening{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

//当键盘出现或改变时调用
- (void)keyboardWillShow:(NSNotification *)aNotification{
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    CGFloat height=keyboardRect.size.height;
    self.boardWillShow(height);
}
//当键退出时调用
- (void)keyboardWillHide:(NSNotification *)aNotification{
    self.boardWillHide();
}
-(void)startlisteningblockcompletion:(keyboardWillShow)boardWillShow keyboard:(keyboardWillHide)boardWillHide
{
    [self startlistening];
    self.boardWillHide = boardWillHide;
    self.boardWillShow = boardWillShow;
}

@end
