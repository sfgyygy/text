//
//  MyTableViewModel.m
//  框架
//
//  Created by Apple on 16/8/18.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "MyTableViewModel.h"

@implementation MyTableViewModel

-(instancetype)init{
    if (self=[super init]) {
        self.CELL_H=200;
    }
    return self;
}
@end
