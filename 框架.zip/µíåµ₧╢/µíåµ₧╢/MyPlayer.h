

#import <UIKit/UIKit.h>

@interface MyPlayer : UIView
/**
 *  初始化方法
 *
 *  @param frame 大小
 *  @param Url   视频地址
 *
 *  @return self;
 */
-(instancetype)initWithFrame:(CGRect)frame withUrl:(NSURL *)Url;
/**
 *  播放
 */
-(void)play;
/**
 *  暂停
 */
-(void)pause;
/**
 *  视频的地址
 */
@property(nonatomic,copy)NSURL * url;



@end
