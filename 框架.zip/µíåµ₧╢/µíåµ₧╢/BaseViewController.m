

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController
#pragma mark-----加载创建自定义的导航栏

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
     self.model = [GerenModel  sharedInstance];
}
-(void)viewDidLoad{
    [super viewDidLoad];
    MyLog(@"当前网络%d",[MyCache sharedInstance].status);
    self.navigationController.navigationBarHidden=YES;
    self.model = [GerenModel sharedInstance];
    [self.view addSubview:[[UIView alloc]init]];
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    if (!self.titlestr) {
        self.navView = [[NavView alloc]initWithFrame:CGRectZero title:[self.dict objectForKey:@"NAVBAR_TITLE_IMAGE_NAME"]];
        [self.navView isfanhuiBtn:NO];
        [self.view addSubview:self.navView];
    }else {
        self.navView = [[NavView alloc]initWithFrame:CGRectZero title:self.titlestr ];
        self.navView.delegate = self;
        [self.navView isfanhuiBtn:YES];
        [self.view addSubview:self.navView];
    }
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillAppear:animated];

}
#pragma mark-----跟视图的创建方法
- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        _dict = dict;
    }
    return self;
}
#pragma mark-----子视图的默认创建方法
-(instancetype)initWithNavTitle:(NSString *)str
{
    self.titlestr = str ;
    if (self=[super init]) {
       
    }
    return self;
}

#pragma mark---下载数据
-(void)getdownDatas:(NSString *)str  index:(int)index
{
    [self getdownDatas:str index:index iscache:NO];
}
-(void)getdownDatas:(NSString *)str index:(int)index iscache:(BOOL)iscache {
    [self createShuaxin];
    NSString * url=[self editorurl:str index:index];
    if (iscache) {
        //缓存已经有数据 不用在保存
        [self parsingresponse:[[MyCache sharedInstance] objectForKey:url] index:index iscache:NO url:url];
        return ;
    }
    //打印字符串
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //设置返回类型为二进制
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    // 3、发送一个GET请求
    [manager GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        id  responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
 
        [self parsingresponse:responseDict index:index iscache:iscache url:url];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self duxucuowu:error index:index];
        self.actView.alpha=0;
    }];
}
#pragma mark---Post
-(void)postdownDatas:(NSString *)str dict:(nullable NSDictionary *)dict index:(int)index {
    [self postdownDatas:str dict:dict index:index iscache:NO];
}
-(void)postdownDatas:(NSString *)str dict:(nullable NSDictionary *)dict index:(int)index iscache:(BOOL)iscache
{
    [self createShuaxin];
    NSString * url = [self editorurl:str index:index];
    NSString * cacheUrl1 = [Helpr DataTOjsonString:dict];
    if (dict == nil) {
        cacheUrl1 = @"dict";
    }
    NSString * cacheUrl = [NSString stringWithFormat:@"%@%@",url,cacheUrl1];
    if (iscache && cacheUrl1) {
        //缓存已经有数据 不用在保存
        [self parsingresponse:[[MyCache sharedInstance] objectForKey:cacheUrl] index:index iscache:NO url:cacheUrl];
    }
    //打印字符串
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //设置返回类型为二进制
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //Post请求
    [manager POST:url parameters:dict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        id responseDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (cacheUrl1) {
            [self parsingresponse:responseDict index:index iscache:iscache url:cacheUrl];
        }else {
            [self parsingresponse:responseDict index:index iscache:NO url:cacheUrl];
        }
       
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [self duxucuowu:error index:index];
        self.actView.alpha=0;
        
    }];

}
/**
 *  解析数据
 *
 *  @param responseDict 下载或者缓存的数据
 *  @param index        标签
 *  @param iscache      是否保存缓存
 *  @param url    保存缓存的键
 */
-(void)parsingresponse:(id)responseDict index:(int)index iscache:(BOOL)iscache url:(NSString *)url
{
#ifdef DEBUG //调试状态 打印
    MyLog(@"index====%d\n==========%@",index,responseDict);
#endif
    //保存缓存
    if (iscache) {
        [[MyCache sharedInstance]setObject:responseDict forKey:url];
    }
    //这返回的是字典
    if (index > -100 && index < 100) {
        if (responseDict) {
            //缓存中已经有数据 不在次保存
            [self parsingresponseDict:(NSDictionary *)responseDict index:index];
        }
    }else {
        //这返回的数组
           [self duxuArray:(NSArray *)responseDict index:index];
    }
    self.actView.alpha=0;
}
#pragma mark-----处理数据
-(void)parsingresponseDict:(NSDictionary *)dict index:(int)index
{
    if ([[dict objectForKey:@"result"]intValue] != 1) {
        [Helpr setalertmessage:[dict objectForKey:@"msg"] delegate:self];
        if ([[dict objectForKey:@"result"]intValue] == 0) {
            [self duxu1:[dict objectForKey:@"obj"] index:index];
        }
    }else {
        [self duxu:[dict objectForKey:@"obj"] index:index];
    }
}
#pragma mark----读取下载数据
-(void)duxu:(NSDictionary *)responseDict index:(int)index
{
    MyLog(@"子类未重写读取数据");
}
-(void)duxu1:(NSDictionary *)responseDict index:(int)index
{
     MyLog(@"子类未重写读取数据");
}

-(void)duxuArray:(NSArray *)dataArray index:(int)index
{
    MyLog(@"子类未重写读取数据");
}
#pragma mark----读取错误信息
-(void)duxucuowu:(NSError *)error index:(int)index
{
    MyLog(@"子类未重写错误");
}
/**
 *  拼接url地址
 *
 *  @param str   后缀
 *  @param index 下载的标签    <0  不拼接字符串    <100 跟>100  请求数据返回的是数组
 *
 *  @return url
 */
-(NSString *)editorurl:(NSString *)str index:(int)index
{
    //正数要拼接字符串  负数不用拼接  style==0转码
    NSString *url=URL(str);  //拼接字符串
    if(index<0)
    {
        url=str; //不拼接字符串ss
    }
    if (![Helpr isChinese:str]) {
        url= [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
#ifdef DEBUG //调试状态 打印字符串
       MyLog(@"%@",url);
#endif
    return url;
}
#pragma mark---创建刷新小按钮
-(void)createShuaxin
{
    if (!self.actView) {
        self.actView = [UIImage downloadingImageActivityIndicatorView:CGRectMake(self.view.bounds.size.width/2-5,self.view.bounds.size.height/2-5 , 10, 10)];
        [self.view addSubview:self.actView];
    }else
    {
        self.actView.alpha=1;
    }
}
#pragma mark-----返回按钮的代理
-(void)didfanhui{
    FANHUI_JIUSHITU;
}
-(void)popControllerwithstr:(NSString *)str title:(NSString *)title
{
    Class cls =  NSClassFromString(str);
    BaseViewController * vc = [[cls alloc]initWithNavTitle:title];
    TUICHU_XINSHITU(vc);
}

@end

@implementation BaseMytabViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
}
-(void)createTableView
{
    MyLog(@"子类请重些这个方法,创建myTableView");
}

@end

