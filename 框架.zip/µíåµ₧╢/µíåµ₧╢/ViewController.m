

#import "ViewController.h"
#import "PhotoViewController.h"

@interface ViewController ()<UIPageViewControllerDataSource,UIPageViewControllerDelegate>
{
    NSMutableArray *idarray;
    
    NSMutableArray *titlearray;
    
    NSMutableArray *itemidarray;
    
    NSMutableArray *picarray;
    
    UIPageViewController *_pageViewController;
    
    NSMutableArray *_vcArray;
    
    UIPageControl *_pageControl;
}
// 保存创建的定时器
@property (nonatomic, retain) NSTimer *timer;

@end

@implementation ViewController


#pragma mark - 当UIPageViewController动画停止时调用此方法
//当动画停止 改变pageControl的当前页
-(void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray *)previousViewControllers transitionCompleted:(BOOL)completed
{
    PhotoViewController *vc=(PhotoViewController *)pageViewController.viewControllers[0];
    NSInteger currentPage = vc.currentPage;
    _pageControl.currentPage = currentPage;
    
}

#pragma mark - UIPageViewController协议
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    PhotoViewController *vc=(PhotoViewController *)viewController;
    NSInteger page = vc.currentPage;
    if (page == 0)
    {
        return _vcArray[_vcArray.count-1];
    }
    return _vcArray[page-1];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    PhotoViewController *vc=(PhotoViewController *)viewController;
    NSInteger page = vc.currentPage;
    if (page == _vcArray.count-1)
    {
        return _vcArray[0];
    }
    return _vcArray[page+1];
}

-(void)prepareData
{
    _vcArray = [[NSMutableArray alloc]init];
    for (int i=0; i<picarray.count; i++)
    {
        PhotoViewController *vc=[[PhotoViewController alloc]initWithFrame:self.bounds];
        vc.currentPage=i;
        vc.imageName = picarray[i];
        [_vcArray addObject:vc];
    }
}

-(void)configPageVC
{
    _pageViewController = [[UIPageViewController alloc]initWithTransitionStyle:1 navigationOrientation:0 options:nil];
    
    [_pageViewController setViewControllers:@[_vcArray[0]] direction:0 animated:NO completion:nil];
    _pageViewController.delegate = self;
    _pageViewController.dataSource = self;
    _pageViewController.view.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    [self addSubview:_pageViewController.view];
    
    _pageControl = [[UIPageControl alloc]init];
    _pageControl.numberOfPages = _vcArray.count;
    _pageControl.currentPage = [_vcArray indexOfObject:_pageViewController.viewControllers[0]];
    _pageControl.center = CGPointMake(SCREEN_WIDTH / 2, self.frame.size.height-10);
    _pageControl.pageIndicatorTintColor=RGB_R(88, 88, 88);
    _pageControl.currentPageIndicatorTintColor=RGB_R(44, 44, 44);
    [_pageViewController.view addSubview:_pageControl];
    
    //添加点击手势
    [self createTapOnceGesture];
}


-(void)setDict:(NSDictionary *)dict
{
    _dict=dict;
    [self createdatas];
    [self prepareData];
    [self configPageVC];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
}
-(void)createdatas
{
    idarray=[NSMutableArray array];
    itemidarray=[NSMutableArray array];
    picarray=[NSMutableArray array];
    titlearray=[NSMutableArray array];
    for (NSDictionary *dict1 in _dict ) {
        [idarray addObject:[dict1 objectForKeyedSubscript:@"positionId"]];
//        [titlearray addObject:[dict1 objectForKeyedSubscript:@"adName"]];
//        [itemidarray addObject:[dict1 objectForKeyedSubscript:@"adId"]] ;
        [picarray addObject:[dict1 objectForKeyedSubscript:@"advertImg"]];
    }
    
}

- (void)updateTimer
{
    NSInteger page = _pageControl.currentPage;
    if (page==_vcArray.count-1) {
        page=0;
    }else
    {
        page++;
    }
    _pageControl.currentPage=page;
    [_pageViewController setViewControllers:@[_vcArray[page]] direction:0 animated:YES completion:nil];
    
}

// 创建单击手势
- (void)createTapOnceGesture
{
    // 创建轻击手势
    UITapGestureRecognizer *tapOnce = [[UITapGestureRecognizer alloc] init];
    // 添加处理手势的方法。
    [tapOnce addTarget:self action:@selector(tapOnce:)];
    // 设置点击的次数，默认为1
    tapOnce.numberOfTapsRequired = 1;
    // 设置需要几个手指同时点击
    tapOnce.numberOfTouchesRequired = 1;
    [self  addGestureRecognizer:tapOnce];
}
// 处理单击手势的方法
- (void)tapOnce:(UITapGestureRecognizer *)ges
{
   //_pageControl
    [_timer setFireDate:[NSDate distantFuture]];
    if ([self.delegate respondsToSelector:@selector(didselsctview:)]) {
        [self.delegate didselsctview:idarray[_pageControl.currentPage]];
    }
    [_timer setFireDate:[NSDate distantPast]];
}
-(void)viewWillAppear:(BOOL)animated
{
    //开启定时器
    [_timer setFireDate:[NSDate distantFuture]];
}

//页面消失，进入后台不显示该页面，关闭定时器
-(void)viewDidDisappear:(BOOL)animated
{
    //关闭定时器
    [_timer setFireDate:[NSDate distantPast]];}
@end
