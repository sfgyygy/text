//
//  YouyiController.m
//  框架
//
//  Created by Apple on 16/9/8.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "YouyiController.h"
#import "YouyiView.h"

@interface YouyiController ()  <YouyiViewDelegate>
@property(nonatomic,retain)YouyiView * youyiView;

@end

@implementation YouyiController

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self createView];
}

-(void)createView{
    self.youyiView = [[YouyiView alloc]initWithFrame:CGRectMake(20, 64, 1, 1)];
    self.youyiView.delegate = self;
    [self.view addSubview:self.youyiView];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    if ([self.youyiView zhunbeijiuxu]) {
        [self.youyiView kaishiBegan:touches withEvent:event];
    }else {
        [self.youyiView zhunbei];
    }
}
-(void)jihaoweijinqiu:(int)index
{
    NSLog(@"%d",index);
    if (index == 0) {
        
    }else if(index == 1){
        
    }else if(index == 2){
        
    }else if(index == 3){
        
    }else if(index == 4){
        
    }else if(index == 5){
        
    }else if(index == 6){
        
    }else if(index ==7){
        
    }else if(index ==8){
        
    }else if(index == 9){
        
    }else if(index ==10){
        
    }else if(index ==11){
        
    }else if(index ==12){
        
    }else if(index ==13){
        
    }else if(index == 14){
        
    }else if(index == 15){
        
    }else if(index ==16){
        
    }else if(index == 17){
        
    }else if(index ==18){
        
    }else if(index == 19){
        
    }else {
        return ;
    }
}
@end
