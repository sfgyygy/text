

#import "MyPlayer.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "CustomPlayerView.h"
@interface MyPlayer ()
{
    //媒体对象，视频对象
    AVPlayerItem *_playerItem;
    //视频播放器
    AVPlayer *_player;
    
    CustomPlayerView * player;
}

@end

@implementation MyPlayer

-(instancetype)initWithFrame:(CGRect)frame withUrl:(NSURL *)Url
{
    if (self = [super initWithFrame:frame]) {
        self.url = Url;
    }
    return self;
}
-(void)play
{
    [_player play];
}
-(void)pause
{
     [_player pause];
}

-(void)setUrl:(NSURL *)url{
    _url = url;
    //创建视频资源对象
    _playerItem = [AVPlayerItem playerItemWithURL:url];
    //创建视频播放器
    _player = [AVPlayer playerWithPlayerItem:_playerItem];
    //创建视频播放器视图
    if (!player) {
        player = [[CustomPlayerView alloc] initWithFrame:self.bounds];
        [self addSubview:player];
    }
    //传入一个AVPlayer对象_player
    player.player = _player;
}

@end
