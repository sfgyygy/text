
#import "RLCButton.h"

@interface RLCButton ()

@property(nonatomic,retain)NSArray *colors;

@property(nonatomic,retain)NSArray *sizes;

@property(nonatomic,assign)CGFloat www;

@property(nonatomic,assign)BOOL isClick;

@property(nonatomic,assign)int  index;

@end

@implementation RLCButton
-(instancetype)initWithFrame:(CGRect)frame colors:(NSArray <UIColor *>*)colors  sizes:(NSArray <NSNumber *> *)sizes{
    if (self=[super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.width)]) {
        _colors=colors;
        _sizes=sizes;
        _www=frame.size.width;
        self.layer.cornerRadius=_www/2;
        _isClick=YES;
        _index=-1;
    }
    return self;
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event{
    if (_isClick) {
        _isClick=NO;
        return _isClick;
    }else{
        _isClick=YES;
    }
    CGFloat X = point.x;
    CGFloat Y = point.y;
    double val=sqrt(pow((X-_www/2.0),2)+pow((Y-_www/2.0),2));
    if (val>_www/2||val<_www/4.0-15) {
        return NO;
    }else{
        CGFloat a = X - _www/2.0;
        CGFloat b = Y - _www/2.0;
        CGFloat c = _www - _www/2.0;
        CGFloat d = _www/2.0 - _www/2.0;
        CGFloat rads = acos(((a*c) + (b*d)) / ((sqrt(a*a + b*b)) * (sqrt(c*c + d*d))));
        float jiaodu =rads*180/M_PI;
        b>0?(jiaodu=jiaodu):(jiaodu=360-jiaodu);
        for (int i=0; i<_sizes.count; i++) {
            if (jiaodu<[_sizes[i] floatValue]) {
                if ([self.delegate respondsToSelector:@selector(didbutton:index:toindex:)]) {
                    [self.delegate didbutton:self index:_index toindex:i];
                    _index=i;
                    i=100000;
                }
            }
        }
    }
    return NO;
}
-(void)drawRect:(CGRect)rect{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 0);
    for (int i=0; i<_colors.count; i++) {
        UIColor * aColor = _colors[i];
        CGContextSetFillColorWithColor(context, aColor.CGColor);
        CGContextMoveToPoint(context, _www/2, _www/2);
        if (i==0) {
            CGContextAddArc(context, _www/2, _www/2, _www/2,  0, [_sizes[i] floatValue] * M_PI / 180, 0);
        }else{
            CGContextAddArc(context, _www/2, _www/2, _www/2,  [_sizes[i-1] floatValue] * M_PI / 180, [_sizes[i] floatValue]* M_PI / 180, 0);
        }
        self.clipsToBounds=NO;
        CGContextClosePath(context);
        CGContextDrawPath(context, kCGPathFillStroke);
    }
    UIColor *color = [UIColor whiteColor];
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextAddArc(context, _www/2, _www/2, _www/4-15,  0, 2*M_PI ,0);
    CGContextDrawPath(context, kCGPathFillStroke);
}
-(void)drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx
{

    
}
@end
