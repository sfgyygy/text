




//------------------------------所有的宏的总类－－－－－－－－－－－－－－－
#import "URLPATH.h"
#import "UiHelpr.h"
#import "AFNetworking.h"
#import "BanbenGengxin.h"
#import "MyColor.h"
#import "MyCache.h"
#import "Danli.h"
#import "Listeningkeyboard.h"

#ifndef MyHelpr_h
#define MyHelpr_h

//屏幕的宽 高
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)

//判断是否是iPhone4
#define isIPhone4 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
//判断是否是iPhone5
#define isIPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
//是否iPhone6
#define isIPhone6  ([UIScreen instancesRespondToSelector:@selector(nativeBounds)] ? CGSizeEqualToSize(CGSizeMake(375.00*2, 667.00*2),[[UIScreen mainScreen] nativeBounds].size) : NO)
//是否iPhone6plus
#define isIPhone6plus ([UIScreen instancesRespondToSelector:@selector(nativeBounds)] ? CGSizeEqualToSize(CGSizeMake(414.000000*3, 736.000000*3),[[UIScreen mainScreen] currentMode].size) : NO)

#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

#define isPadmini  ([UIScreen instancesRespondToSelector:@selector(nativeBounds)] ? CGSizeEqualToSize(CGSizeMake(768.000000*2, 1024.000000*2),[[UIScreen mainScreen] currentMode].size) : NO)


//进入新视图
#define TUICHU_XINSHITU(NAV) [self.navigationController pushViewController:NAV animated:YES]
//返回上一个视图
#define FANHUI_JIUSHITU  [self.navigationController popViewControllerAnimated:YES]
//字符串变方法
#define SEL_ZIFUCHUAN(a)  NSSelectorFromString(a)

#define SEL_ZIFUCHUAN1(a) [self performSelector:SEL_ZIFUCHUAN_FANGFA(a)]
//字符串转CLass
#define CLASS_ZIFUCHUAN(a)  NSClassFromString(a)
//方法转字符串
#define SEL_ZHUAN_ZIFUCHUAN(a) NSStringFromSelector(a)
//类名转字符串
#define CLASS_ZHUANG_ZIFUCHUAN(a) NSStringFromClass(a)

#endif /* MyHelpr_h */
