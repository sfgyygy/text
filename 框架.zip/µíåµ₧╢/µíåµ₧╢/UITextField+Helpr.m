//
//  UITextField+Helpr.m
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "UITextField+Helpr.h"

@implementation UITextField (Helpr)

-(instancetype)initWithfram:(CGRect)fram placeholder:(NSString *)placeholder borderStyle:(UITextBorderStyle )borderStyle
{
    if (self = [self initWithFrame:fram]) {
        self.keyboardType = UIKeyboardTypeDefault;
        self.backgroundColor = [UIColor whiteColor];
        self.placeholder = placeholder;
        self.borderStyle =borderStyle;
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return self ;
}

-(instancetype)initWithfram:(CGRect)fram mimaplaceholder:(NSString *)placeholder borderStyle:(UITextBorderStyle )borderStyle
{
    if (self = [self initWithFrame:fram]) {
        self.keyboardType = UIKeyboardTypeDefault;
        self.backgroundColor = [UIColor whiteColor];
        self.placeholder = placeholder;
        self.borderStyle =borderStyle;
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.secureTextEntry = YES;
    }
    return self;
}

@end
