
//----------------------保存网络请求的一些缓存数据

#import <Foundation/Foundation.h>
#import "AFNetworkReachabilityManager.h"

@interface MyCache : NSObject

XMGSingletoH
/**
 *  保存缓存数据
 */
-(void)setObject:(id)value forKey:(NSString *)url;
/**
 *  取数据
 */
-(id)objectForKey:(NSString *)url;
/**
 *  移除缓存数据
 */
-(void)removeKey:(NSString *)url;
/**
 *  移除所有缓存数据
 */
-(void)removeallKey;
/**
 *  当前网络状态   -1 无网络  1  未知网络  2 wifi  3 运营商  0检测中
 */
@property(nonatomic,assign)int status;
/**
 *  检测网络  -1 无网络  1  未知网络  2 wifi  3 运营商
 */
-(void)Detectnetwork;
@end
