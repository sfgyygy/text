//
//  NvshenController.m
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "NvshenController.h"

@implementation NvshenController

-(void)viewDidLoad
{
    [super viewDidLoad];
    UITextView * tx = [[UITextView alloc]initWithfram:CGRectMake(10, 100, 100, 60) placeholder:@"sssssss"];
    [self.view addSubview:tx];
    UITextView * tx1 = [[UITextView alloc]initWithfram:CGRectMake(10, 200, 100, 60) placeholder:@"测试件键盘111"];
    [self.view addSubview:tx1];

}
@end
