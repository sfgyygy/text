//
//  YouyiController.h
//  框架
//
//  Created by Apple on 16/9/8.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "BaseViewController.h"

@interface YouyiController : BaseViewController

@end
