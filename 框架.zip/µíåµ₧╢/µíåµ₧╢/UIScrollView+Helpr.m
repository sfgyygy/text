//
//  UIScrollView+Helpr.m
//  框架
//
//  Created by Apple on 16/9/2.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "UIScrollView+Helpr.h"



@implementation UIScrollView (Helpr)

@dynamic keyboard;
@dynamic dataSource;

__strong Listeningkeyboard * _keyboard;
__strong id <UIScrollViewDataSource >_dataSource;

-(Listeningkeyboard *)keyboard
{
    if (_keyboard == nil) {
        _keyboard = [[Listeningkeyboard alloc]init];
    }
    return _keyboard;
}

-(void)setKeyboard:(Listeningkeyboard *)keyboard{
    _keyboard = keyboard;
}

-(void)setDataSource:(id<UIScrollViewDataSource>)dataSource
{
    _dataSource = dataSource;
}
-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor isKeyboard:(BOOL)isKeyboard{
    if (self = [super initWithFrame:frame bgColor:bgColor]) {
        self.showsHorizontalScrollIndicator = YES;
        self.showsVerticalScrollIndicator = YES;
        if (isKeyboard) {
            [self.keyboard startlisteningblockcompletion:^(CGFloat h) {
                MyLog(@"键盘上来了");
                self.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.height - h);
                if ([_dataSource respondsToSelector:@selector(keyboardshangshen:floath:)]) {
                    [_dataSource keyboardshangshen:self floath:h];
                }
            } keyboard:^{
                self.frame = frame;
                  MyLog(@"键盘下去了");
                if ([_dataSource respondsToSelector:@selector(keyboardxiajiang:)]) {
                    [_dataSource keyboardxiajiang:self];
                }
            }];
        }
    }
    return self;
}
-(void)dealloc
{
    if (self.keyboard) {
        [self.keyboard stoplistening];
    }
}
@end
