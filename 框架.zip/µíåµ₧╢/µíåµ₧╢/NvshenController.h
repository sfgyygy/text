//
//  NvshenController.h
//  框架
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 框架. All rights reserved.
//

#import "BaseViewController.h"


@interface NvshenController : BaseMytabViewController

@end
